'use strict';
/* In-app companion controller. No background permission, OS overlay or network API. */
const PET_MOTION_MATH=(()=>{
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
 function clipDurationMs(clip){const ms=Number.isFinite(clip?.durationMs)?clip.durationMs:Number.isFinite(clip?.duration)?clip.duration*1000:Number.isFinite(clip?.frameCount)&&Number.isFinite(clip?.fps)&&clip.fps>0?clip.frameCount/clip.fps*1000:0;return ms>0?clamp(ms,100,60000):0}
 function safeMediaPath(src,extensions){return typeof src==='string'&&!src.includes('..')&&new RegExp('^assets/(?:motion|interactions)/[a-zA-Z0-9_.\\/-]+\\.('+extensions+')$','i').test(src)}
 const intersect=(a,b)=>a.left<b.right&&a.right>b.left&&a.top<b.bottom&&a.bottom>b.top;
 function pointClear(p,box,obstacles,padX=0,padY=0){if(p.x<box.left+padX||p.x>box.right-padX||p.y<box.top+padY||p.y>box.bottom-padY)return false;return !obstacles.some(o=>p.x>o.left-padX&&p.x<o.right+padX&&p.y>o.top-padY&&p.y<o.bottom+padY)}
 function segmentClear(a,b,box,obstacles,padX,padY){const count=Math.max(1,Math.ceil(distance(a,b)/7));for(let i=0;i<=count;i++){const t=i/count;if(!pointClear({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t},box,obstacles,padX,padY))return false}return true}
 function grid(box,obstacles,width,height,step=22){const points=[],padX=width/2+4,padY=height/2+3;let row=0;for(let y=box.top+padY;y<=box.bottom-padY+.1;y+=step,row++){let col=0;for(let x=box.left+padX;x<=box.right-padX+.1;x+=step,col++){if(pointClear({x,y},box,obstacles,padX,padY))points.push({x,y,row,col})}}return {points,box,obstacles,padX,padY,step}}
 function groundField(box,obstacles,width,height,step=22){const points=[],padX=width/2+4,padY=height/2,y=box.bottom-padY;let col=0;for(let x=box.left+padX;x<=box.right-padX+.1;x+=step,col++){if(pointClear({x,y},box,obstacles,padX,padY))points.push({x,y,row:0,col})}const right=box.right-padX;if(points.length&&right-points[points.length-1].x>1&&pointClear({x:right,y},box,obstacles,padX,padY))points.push({x:right,y,row:0,col});return {points,box,obstacles,padX,padY,step,groundY:y,floorY:box.bottom}}
 function combineAlpha(rgb,mask){if(!rgb?.data||!mask?.data||rgb.data.length!==mask.data.length)throw new Error('Packed alpha panels differ');for(let i=0;i<rgb.data.length;i+=4)rgb.data[i+3]=mask.data[i];return rgb}
 function nearest(points,p){let best=-1,d=Infinity;points.forEach((n,i)=>{const next=distance(n,p);if(next<d){best=i;d=next}});return best}
 function path(field,start,targetIndex){const points=field.points;if(!points.length||targetIndex<0||targetIndex>=points.length)return [];const startIndex=nearest(points,start),end=points[targetIndex];if(segmentClear(start,end,field.box,field.obstacles,field.padX,field.padY))return [{x:end.x,y:end.y}];const map=new Map(points.map((p,i)=>[p.row+':'+p.col,i]));const queue=[startIndex],prev=new Map([[startIndex,-1]]);for(let h=0;h<queue.length;h++){const i=queue[h];if(i===targetIndex)break;const p=points[i];for(const [dr,dc]of [[0,1],[1,0],[0,-1],[-1,0]]){const n=map.get((p.row+dr)+':'+(p.col+dc));if(n===undefined||prev.has(n))continue;prev.set(n,i);queue.push(n)}}if(!prev.has(targetIndex))return [];const route=[];let at=targetIndex;while(at!==-1){route.push({x:points[at].x,y:points[at].y});at=prev.get(at)}route.reverse();const result=[];let anchor=start,idx=0;while(idx<route.length){let far=idx;for(let j=idx;j<route.length;j++){if(segmentClear(anchor,route[j],field.box,field.obstacles,field.padX,field.padY))far=j;else break}result.push(route[far]);anchor=route[far];idx=far+1}return result}
 function steer(position,velocity,target,speed,dt){const d=distance(position,target);const desired=d>.001?{x:(target.x-position.x)/d*speed,y:(target.y-position.y)/d*speed}:{x:0,y:0};const response=1-Math.exp(-3.2*dt);const nextVelocity={x:velocity.x+(desired.x-velocity.x)*response,y:velocity.y+(desired.y-velocity.y)*response};return {position:{x:position.x+nextVelocity.x*dt,y:position.y+nextVelocity.y*dt},velocity:nextVelocity}}
 return {clamp,distance,intersect,pointClear,segmentClear,grid,groundField,nearest,path,steer,clipDurationMs,safeMediaPath,combineAlpha};
})();
const PetMotion=(()=>{
 let videoFrameHandle=null,presentedVideoFrames=0,transitionCanvas=null,transitionCtx=null,transitionPending=false,transitionSerial=0;
 let initialized=false,layer=null,actor=null,sprite=null,canvas=null,animated=null,video=null,rawCanvas=null,ctx=null,rawCtx=null;
 let frame=0,lastFrame=0,lastDraw=0,dirty=true,field=null,box=null,scene=null,phone=null,route='',visualKey='',clipKey='',activeClip=null,mediaFailed=false,mediaPending=false;
 let atlasMeta=null,atlasEntry=null,atlasStartedAt=0,renderSource='still',motionFallback=null;const atlasCache=new Map(),failedClips=new Set(),imageBlobCache=new Map();
 let actionAtlasHoldUntil=0,actionAtlasLastFrame=-1,lastAutoStart=-Infinity,climbEntryDone=false;
 let phaseSerial=0;const clipVariantCache=new Map(),clipVariantCounters=new Map();
 let imageGeneration=0,imageActive=false,imagePending=false,imageStartedAt=0,imageDeadline=0,imageSettled=false,imageObjectURL=null,imagePoster=null,settledPoseUntil=0;
 let position=null,velocity={x:0,y:0},path=[],phase='idle',phaseUntil=0,forcedUntil=0,forcedState=null,mediaTick=0,geometryStamp=0,resizeObserver=null,dialogObserver=null;
 let napKind=null,wakeRequests=0,wakeRequestedAt=0,wakeBubbleUntil=0,sleepHoldPose=false,lastWakeAt=-Infinity,wakeTouch=null,wakeBubble=null;
 let interactionAction=null,autoNapUntil=0,parkIntent=false,parkArrivalPending=false,parkedUntil=0;
 let navEdgeY=null,peekIntent=false,peekArrivalPending=false,peekStartedAt=0,peekOffset=0,peekDuration=0,lastPeekAt=-Infinity;
 let reduced=null,cleanup=[];const FPS=30,MAX_VIDEO_FPS=60;
 const currentPet=()=>typeof S!=='undefined'&&S.petState?S.petState:null;
 const adopted=()=>!!currentPet()?.locked;
 const stage=()=>typeof petStageIndex==='function'?petStageIndex():0;
 const setting=()=>S.petSettings||{};
 const enabled=()=>adopted()&&setting().roaming!==false&&setting().animations!==false&&!reduced?.matches;
 const typing=()=>{const el=document.activeElement;return !!el&&el.matches('input,textarea,select,[contenteditable="true"]')};
 const blocked=()=>document.hidden||typing()||!!document.querySelector('dialog[open]');
 const now=()=>typeof performance!=='undefined'?performance.now():Date.now();
 const escape=s=>typeof esc==='function'?esc(s):String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function listen(target,name,fn,options){target.addEventListener(name,fn,options);cleanup.push(()=>target.removeEventListener(name,fn,options))}
 function profile(){const pet=currentPet(),age=stage();const config=pet?.type==='dog'?{speed:30,pause:10000,burst:40,w:84,h:72}:age===0?{speed:29,pause:9000,burst:43,w:156,h:88}:age===1?{speed:24,pause:10500,burst:33,w:166,h:96}:{speed:18,pause:12000,burst:25,w:178,h:104};const scale=scene&&['pet','room'].includes(route)?route==='pet'?1.45:1.18:1;return {...config,w:Math.round(config.w*scale),h:Math.round(config.h*scale)}}
 function setPhase(next,hold=0){if(phase!==next){phase=next;phaseSerial++;clipKey=null;if(layer)layer.dataset.state=next}phaseUntil=now()+hold;lastDraw=0}
 function createLayer(){if(layer?.isConnected)return;layer=document.createElement('div');layer.className='pm-layer';layer.setAttribute('role','group');layer.setAttribute('aria-label','Питомец');layer.setAttribute('aria-hidden','true');layer.innerHTML='<div class="pm-actor"><span class="pm-still" aria-hidden="true"></span><img class="pm-animated-image" alt="" hidden><canvas class="pm-canvas" aria-hidden="true"></canvas><canvas class="pm-transition-canvas" aria-hidden="true" hidden></canvas><span class="pm-sleep-mark" aria-hidden="true">z</span><button class="pm-wake-touch" type="button" hidden></button><span class="pm-wake-bubble" role="status" aria-live="polite" hidden></span></div>';document.body.append(layer);actor=layer.querySelector('.pm-actor');sprite=layer.querySelector('.pm-still');animated=layer.querySelector('.pm-animated-image');canvas=layer.querySelector('canvas');transitionCanvas=layer.querySelector('.pm-transition-canvas');transitionCtx=transitionCanvas?.getContext('2d');wakeTouch=layer.querySelector('.pm-wake-touch');wakeBubble=layer.querySelector('.pm-wake-bubble');if(wakeTouch)wakeTouch.addEventListener('click',()=>requestWake('touch'));canvas.width=168;canvas.height=168;ctx=canvas.getContext('2d',{willReadFrequently:false});rawCanvas=document.createElement('canvas');rawCtx=rawCanvas.getContext('2d',{willReadFrequently:true});video=document.createElement('video');video.muted=true;video.defaultMuted=true;video.playsInline=true;video.loop=true;video.preload='metadata';video.setAttribute('playsinline','');video.setAttribute('webkit-playsinline','');video.setAttribute('aria-hidden','true');video.className='pm-source-video';layer.append(video);video.addEventListener('error',()=>{mediaFailed=true;if(activeClip?.src)failedClips.add(activeClip.src);clipKey=null;showStill()});video.addEventListener('loadeddata',()=>{if(activeClip&&activeClip.kind!=='animated-image'&&!activeClip.durationMs&&Number.isFinite(video.duration))activeClip.durationMs=video.duration*1000;mediaPending=false;if(enabled()&&!blocked()&&layer&&!layer.hidden)startMedia()});video.addEventListener('ended',()=>{if(activeClip&&activeClip.kind!=='animated-image'&&activeClip.loopSafe!==true)finishOneShot(now())});}
 function removeLegacyMotionUi(){document.querySelectorAll('.pm-lane,.pm-lane-caption,.pm-lane-toggle,.pm-parked').forEach(el=>el.remove())}
 function alphaStillPoster(){
  const pet=currentPet();if(pet?.type!=='cat'||pet.breed!==0)return null;
  const clip=resolveClip();const poster=clip?.poster;
  return ['animated-image','alpha-video'].includes(clip?.kind)&&clip.keyWhite===false&&PET_MOTION_MATH.safeMediaPath(poster,'png|webp')?poster:null;
 }
 function visual(){const pet=currentPet();const key=[pet?.type,pet?.breed,stage()].join(':');if(key!==visualKey){visualKey=key;clipKey=null;atlasMeta=null;activeClip=null;mediaFailed=false;showStill();const poster=alphaStillPoster();sprite.innerHTML=poster?`<img class="pm-alpha-still" src="${escape(poster)}" alt="">`:typeof petMascot==='function'?petMascot('pm-roaming-sprite'):'';actor.dataset.species=pet?.type==='dog'?'dog':'cat';actor.dataset.age=stage();}const p=profile();actor.style.width=p.w+'px';actor.style.height=p.h+'px';actor.style.setProperty('--pm-still-size',p.h+'px');}
 function restoreStage(){document.querySelectorAll('[data-pm-original-hidden]').forEach(el=>{el.removeAttribute('data-pm-original-hidden')})}
 function hide(){transitionSerial++;transitionPending=false;if(transitionCanvas)transitionCanvas.hidden=true;if(layer)layer.hidden=true;restoreStage();stop();}
 function stop(){cancelNativeVideoFrame();if(frame){cancelAnimationFrame(frame);frame=0}lastFrame=0;if(video&&!video.paused)video.pause();stopAnimated();clipKey=null;}
 function getBox(){
  const app=document.querySelector('.phone #app');phone=document.querySelector('.phone');if(!app||!phone)return null;
  const header=phone.querySelector('header'),nav=phone.querySelector('nav'),r=app.getBoundingClientRect(),pr=phone.getBoundingClientRect();
  const h=header?.getBoundingClientRect(),n=nav?.getBoundingClientRect(),viewportHeight=window.visualViewport?.height||window.innerHeight,viewportTop=window.visualViewport?.offsetTop||0,viewportBottom=viewportTop+viewportHeight;
  navEdgeY=n&&n.top>viewportTop&&n.top<viewportBottom?n.top:null;
  // The navigation edge is the only walking surface on ordinary screens.
  // There is no traversable space in the middle of a card, heading or image.
  let available={left:Math.max(0,pr.left,r.left)+8,right:Math.min(window.innerWidth,pr.right,r.right)-8,top:Math.max(viewportTop,r.top,h&&h.bottom>viewportTop?h.bottom:viewportTop)+6,bottom:navEdgeY??viewportBottom};
  const special=route==='room'?app.querySelector('.ps-room'):null;scene=null;
  if(special){const sr=special.getBoundingClientRect(),clip={left:Math.max(available.left,sr.left+9),right:Math.min(available.right,sr.right-9),top:Math.max(available.top,sr.top+46),bottom:Math.min(available.bottom,sr.bottom-24)};if(clip.right-clip.left>105&&clip.bottom-clip.top>96){available=clip;scene=special}}
  return {available,app};
 }
 function softCost(point,fieldToUse=field){
  const p=profile(),area=p.w*p.h;let score=0;
  for(const o of fieldToUse?.softObstacles||[]){const w=Math.max(0,Math.min(point.x+p.w/2,o.right)-Math.max(point.x-p.w/2,o.left)),h=Math.max(0,Math.min(point.y+p.h/2,o.bottom)-Math.max(point.y-p.h/2,o.top));score+=w*h/area}
  return score;
 }
 function hideDuplicateArt(app){
  app.querySelectorAll('.intro .ps-mascot,.banner .ps-mascot,.ex-home-intro .ps-mascot,[data-pet-hero]').forEach(el=>el.setAttribute('data-pm-original-hidden','true'));
  if(scene){const original=scene.querySelector(route==='room'?'.ps-room-pet':'.ps-pet-actor');if(original)original.setAttribute('data-pm-original-hidden','true')}
 }
 function initialPoint(_app,p){
  // Until a real climb/down clip exists, enter beside the navigation rather
  // than inventing an unsupported walk from an upper-right illustration.
  return {x:box.right-p.w/2-10,y:box.bottom-p.h/2};
 }
 function readGeometry(){
  dirty=false;geometryStamp=now();const found=getBox();if(!found){hide();return false}
  const {available,app}=found,p=profile();actor.style.width=p.w+'px';actor.style.height=p.h+'px';actor.style.setProperty('--pm-still-size',p.h+'px');
  if(available.right-available.left<p.w+16||available.bottom-available.top<p.h+16){hide();return false}
  box=available;const root=scene||app,obstacles=[],softObstacles=[];
  for(const el of root.querySelectorAll('input,textarea,select,[contenteditable="true"]')){
   const r=el.getBoundingClientRect();if(r.width<2||r.height<2||!PET_MOTION_MATH.intersect(r,available))continue;
   obstacles.push({left:r.left-3,right:r.right+3,top:r.top-3,bottom:r.bottom+3});
  }
  for(const el of root.querySelectorAll('button,a,summary')){
   const r=el.getBoundingClientRect();if(r.width<2||r.height<2||!PET_MOTION_MATH.intersect(r,available))continue;
   softObstacles.push({left:r.left,right:r.right,top:r.top,bottom:r.bottom});
   if(el===document.activeElement){const w=Math.min(88,r.width),h=Math.min(40,r.height);obstacles.push({left:r.left+(r.width-w)/2,right:r.left+(r.width+w)/2,top:r.top+(r.height-h)/2,bottom:r.top+(r.height+h)/2})}
  }
  field=PET_MOTION_MATH.groundField(box,obstacles,p.w,p.h,20);field.softObstacles=softObstacles;
  if(!field.points.length){hide();return false}
  const preferred=position||initialPoint(app,p);
  if(!position||Math.abs(position.y-field.groundY)>.01||!PET_MOTION_MATH.pointClear(position,box,obstacles,field.padX,field.padY)){
   const i=PET_MOTION_MATH.nearest(field.points,preferred);position={x:field.points[i].x,y:field.points[i].y};velocity={x:0,y:0};path=[];setPhase('idle',8500+Math.random()*3500);
  }
  layer.dataset.surface=scene?'room-floor':'navigation-edge';layer.dataset.floorY=box.bottom.toFixed(2);layer.dataset.grounded='true';
  layer.style.left=box.left+'px';layer.style.top=box.top+'px';layer.style.width=(box.right-box.left)+'px';layer.style.height=(box.bottom-box.top)+'px';layer.classList.toggle('pm-in-scene',!!scene);
  restoreStage();hideDuplicateArt(app);return true;
 }
 function visibleToys(){if(!scene||!['pet','room'].includes(route))return [];return [...scene.querySelectorAll('.ps-furniture-teaser,.ps-furniture-tower,[data-pet-toy]')].map(el=>el.getBoundingClientRect()).filter(r=>r.width>0&&r.height>0&&PET_MOTION_MATH.intersect(r,box))}
 function choosePath(){
  if(!field?.points.length||currentPet()?.type!=='cat'||currentPet()?.breed!==0)return false;
  let candidates=field.points.map((p,i)=>({i,d:PET_MOTION_MATH.distance(p,position),cost:softCost(p)*130+Math.random()*55+Math.min(p.x-box.left,box.right-p.x)*.12})).filter(x=>x.d>45&&x.d<Math.max(150,(box.right-box.left)*1.3));
  const toys=visibleToys();
  if(toys.length&&Math.random()<.6){const toy=toys[Math.floor(Math.random()*toys.length)],target={x:toy.left-profile().w/2-8,y:field.groundY};candidates.sort((a,b)=>PET_MOTION_MATH.distance(field.points[a.i],target)-PET_MOTION_MATH.distance(field.points[b.i],target))}
  else candidates.sort((a,b)=>a.cost-b.cost);
  for(const candidate of candidates.slice(0,36)){const found=PET_MOTION_MATH.path(field,position,candidate.i);if(found.length){path=found;interactionAction=null;setPhase('walk');return true}}
  return false;
 }
 const INTERACTION_ALIASES={feed:['feed','eat','food','treat','snack'],treat:['treat','snack'],snack:['snack','treat'],whip:['whip'],walk:['walk','sidewalk'],teaser:['teaser','wand','feather'],ball:['ball'],fish:['fish'],sleep:['sleep'],rest:['rest'],wake:['wake','wakeup','stretch'],peek:['peek','entry','rise','nav-entry'],sit:['sit','upper-right','park'],'upper-right':['upper-right','park','sit'],reluctant:['reluctant','sleepy-glance'],groom:['groom','wash'],climb:['climb','nav-entry'],play:['play','teaser','ball','fish','whip']};
 function applicableClip(raw){
  if(!raw||typeof raw!=='object')return typeof raw==='string';
  if(raw.breed!==undefined&&![0,'orange','orange-tabby'].includes(raw.breed))return false;
  if(Number.isInteger(raw.stage))return raw.stage===stage();
  if(Array.isArray(raw.stages))return raw.stages.includes(stage());
  if(Number.isInteger(raw.sourceStage))return raw.sourceStage===stage();
  return raw.stage===undefined||raw.stage===null;
 }
 function interactionCandidates(action){
  const pet=currentPet();if(pet?.type!=='cat'||pet.breed!==0)return [];
  let manifest;try{manifest=typeof PET_INTERACTION_CLIPS!=='undefined'?PET_INTERACTION_CLIPS:null}catch{return []}if(!manifest)return [];
  const aliases=INTERACTION_ALIASES[action]||[action];const flat=Array.isArray(manifest)?manifest:Array.isArray(manifest.clips)?manifest.clips:null;
  let sources=[];
  if(flat)sources=flat.filter(x=>aliases.includes(x?.action||x?.state));
  else for(const key of aliases){const raw=manifest[key];if(raw)sources.push(...(Array.isArray(raw)?raw:[raw]));}
  sources=sources.filter(applicableClip);sources=sources.filter((raw,i)=>sources.findIndex(x=>(typeof x==='string'?x:x?.src)===(typeof raw==='string'?raw:raw?.src))===i);
  return sources.filter(raw=>action!=='sleep'||raw.depictsSleep===true||raw.action==='sleep'||raw.state==='sleep'||raw.action===undefined&&raw.depictsSleep!==false);
 }
 function selectVariant(source,key){
  if(!Array.isArray(source))return source;if(!source.length)return null;
  const variantKey=stage()+':'+key+':'+phaseSerial;
  if(!clipVariantCache.has(variantKey)){const counterKey=stage()+':'+key,index=clipVariantCounters.get(counterKey)||0;clipVariantCache.set(variantKey,index%source.length);clipVariantCounters.set(counterKey,index+1);if(clipVariantCache.size>100)clipVariantCache.delete(clipVariantCache.keys().next().value)}
  return source[clipVariantCache.get(variantKey)%source.length];
 }
 function normalizeClip(source,state,interaction=false){
  if(!source)return null;const clip=typeof source==='string'?{src:source,keyWhite:true}:{...source};if(typeof clip.qaStatus==='string'&&(clip.qaStatus==='rejected'||clip.qaStatus.startsWith('draft')))return null;
  clip.kind=clip.kind==='animated-image'?'animated-image':clip.kind==='alpha-video'?'alpha-video':'video';
  if(clip.kind==='alpha-video'&&(clip.alphaLayout!=='side-by-side'||!Number.isInteger(clip.contentWidth)||!Number.isInteger(clip.contentHeight)||clip.contentWidth<16||clip.contentWidth>2048||clip.contentHeight<16||clip.contentHeight>2048))return null;
  if(!PET_MOTION_MATH.safeMediaPath(clip.src,clip.kind==='animated-image'?'webp|apng':'mp4|webm'))return null;
  clip.state=state;clip.durationMs=PET_MOTION_MATH.clipDurationMs(clip);clip.loopSafe=clip.loopSafe===true;
  clip.endPoster=PET_MOTION_MATH.safeMediaPath(clip.endPoster||clip.lastFramePoster,'png|webp')?(clip.endPoster||clip.lastFramePoster):null;
  clip.interaction=interaction;clip.depictsSleep=clip.depictsSleep===true||clip.action==='sleep';
  return clip;
 }
 function ownBaseClip(actions){
  const pet=currentPet();if(pet?.type!=='cat'||pet.breed!==0)return null;
  let manifest;try{manifest=typeof PET_MOTION_CLIPS!=='undefined'?PET_MOTION_CLIPS:null}catch{return null}
  if(!manifest)return null;if(!Array.isArray(manifest)&&Array.isArray(manifest.clips))manifest=manifest.clips;
  if(Array.isArray(manifest)){for(const action of actions){const found=manifest.find(x=>x&&x.stage===stage()&&(x.action===action||x.state===action)&&(x.breed===undefined||x.breed===0||x.breed==='orange-tabby'));if(found)return found}return null}
  const age=stage(),group=manifest[age]||manifest[String(age)]||manifest[['kitten','young','adult'][age]]||manifest.orange?.[age]||manifest.orange?.[['kitten','young','adult'][age]];
  for(const action of actions)if(group?.[action])return Array.isArray(group[action])?group[action][0]:group[action];return null;
 }
 function generatedAction(){return null} // Draft pose atlases are disabled pending continuous footage.
 function sleeping(){return napKind!==null||currentPet()?.behavior==='sleep'||phase==='sleep'||phase==='reluctant'}
 function notifyPetState(reason){if(typeof CustomEvent==='function'&&typeof window.dispatchEvent==='function')window.dispatchEvent(new CustomEvent('hanyutun:petstate',{detail:{sleeping:sleeping(),napKind,napUntil:autoNapUntil,wakeRequests,reason}}))}
 function clearNap(reason){const was=sleeping();napKind=null;autoNapUntil=0;wakeRequests=0;wakeRequestedAt=0;wakeBubbleUntil=0;sleepHoldPose=false;if(currentPet()?.behavior==='sleep'){currentPet().behavior='idle';if(typeof save==='function')save()}if(was){if(phase==='sleep'||phase==='reluctant')returnToIdle(800);lastWakeAt=now();notifyPetState(reason||'awake')}}
 function beginNap(kind='manual'){
  napKind=kind;autoNapUntil=now()+(kind==='autonomous'?90000+Math.random()*60000:120000+Math.random()*120000);wakeRequests=0;wakeRequestedAt=0;wakeBubbleUntil=0;sleepHoldPose=false;parkIntent=false;parkedUntil=0;
  if(currentPet()&&currentPet().behavior!=='sleep'){currentPet().behavior='sleep';if(typeof save==='function')save()}
  startInteraction('sleep',autoNapUntil-now());notifyPetState('nap-start');
 }
 function finishNap(reason='nap-complete'){
  clearNap(reason);if(hasInteraction('wake')||ownBaseClip(['wake','stretch']))startInteraction('wake',2800);else returnToIdle(1800);
 }
 function resumeSleepPose(){sleepHoldPose=true;interactionAction='sleep';path=[];velocity={x:0,y:0};setPhase('sleep',Math.max(0,autoNapUntil-now()))}
 function requestWake(source='touch'){
  if(!initialized)init();if(!adopted()||!sleeping())return false;
  if(napKind&&now()>=autoNapUntil){finishNap();update();return true}
  if(!napKind)beginNap('manual');
  if(wakeRequests>0){wakeRequests++;finishNap('second-wake-request');update();return true}
  wakeRequests=1;wakeRequestedAt=now();wakeBubbleUntil=wakeRequestedAt+4200;autoNapUntil=wakeRequestedAt+6500+Math.random()*3000;
  if(currentPet()&&currentPet().behavior!=='sleep'){currentPet().behavior='sleep';if(typeof save==='function')save()}
  if(hasContinuousAction('reluctant'))startInteraction('reluctant',autoNapUntil-now());
  // With no matching turn footage, keep this pet's actual sleeping pose.
  notifyPetState(source==='call'?'called-gently':'touched-gently');update();return true;
 }
 function syncWakeUi(t){
  const asleep=sleeping();if(wakeTouch){wakeTouch.hidden=!asleep;wakeTouch.setAttribute('aria-label','Разбудить '+(S.pet||'питомца'));wakeTouch.title='Погладить и позвать'}
  if(wakeBubble){wakeBubble.hidden=!(wakeBubbleUntil>t);if(!wakeBubble.hidden)wakeBubble.textContent=t-wakeRequestedAt<1100?(S.pet||'Бао')+', просыпайся…':'Ещё минутку…'}
  if(layer){layer.setAttribute('aria-hidden',asleep?'false':'true');layer.dataset.sleeping=asleep?'true':'false';layer.dataset.wakeRequests=String(wakeRequests)}
 }
 function hasContinuousAction(action){return interactionCandidates(action).some(raw=>{const clip=normalizeClip(raw,action,true);return clip&&['alpha-video','video'].includes(clip.kind)&&(!raw.qaStatus||raw.qaStatus==='accepted')})}
 function hasInteraction(action){return !!generatedAction(action)||interactionCandidates(action).some(x=>normalizeClip(x,action,true))||(action==='wake'&&!!ownBaseClip(['wake','stretch']))}
 function resolveClip(){
  const pet=currentPet();if(pet?.type!=='cat'||pet.breed!==0)return null;
  if(phase==='reluctant')return normalizeClip(selectVariant(interactionCandidates('reluctant'),'interaction:reluctant'),'reluctant',true);
  if(phase==='wake'){const matching=ownBaseClip(['wake','stretch']);if(matching)return normalizeClip(matching,'wake',true)}
  const action=interactionAction||(['feed','treat','snack','whip','teaser','ball','fish','wake','sit','sleep','walk','peek'].includes(phase)?phase:null);
  if(action){const selected=selectVariant(interactionCandidates(action),'interaction:'+action);const interaction=normalizeClip(selected,phase,true);if(interaction)return interaction}
  let manifest;try{manifest=typeof PET_MOTION_CLIPS!=='undefined'?PET_MOTION_CLIPS:null}catch{return null}if(!manifest)return null;if(!Array.isArray(manifest)&&Array.isArray(manifest.clips))manifest=manifest.clips;
  const age=stage(),wanted=phase==='walk'?'walk':phase==='play'?'play':phase==='sleep'?'sleep':'idle';let source=null;
  if(Array.isArray(manifest)){
   const find=state=>manifest.find(x=>x&&x.stage===age&&(x.state===state||x.action===state)&&(x.breed===undefined||x.breed===0||x.breed==='orange-tabby'));
   source=find(wanted);if(wanted==='play'){const variants=manifest.filter(x=>x&&x.stage===age&&['play','turn','stretch'].includes(x.state||x.action)&&(x.breed===undefined||x.breed===0||x.breed==='orange-tabby'));if(variants.length>1)source=variants}if(!source&&wanted==='walk')source=find('run');if(!source&&wanted==='play')source=find('turn')||find('stretch');if(!source&&wanted==='idle')source=find('rest');
  }else{const group=manifest[age]||manifest[String(age)]||manifest[['kitten','young','adult'][age]]||manifest.orange?.[age]||manifest.orange?.[['kitten','young','adult'][age]];source=group?.[wanted]||(wanted==='walk'?group?.run:null)||(wanted==='play'?group?.turn||group?.stretch:null)||(wanted==='idle'?group?.rest:null)}
  return normalizeClip(selectVariant(source,'base:'+wanted),wanted,false);
 }
 function startInteraction(action,hold=0){
  if(action!=='peek'){peekIntent=false;peekArrivalPending=false;peekStartedAt=0;peekOffset=0}
  interactionAction=action;path=[];velocity={x:0,y:0};forcedState=null;forcedUntil=0;
  const next=action==='upper-right'?'sit':action;
  if(phase===next){phaseSerial++;clipKey=null}
  setPhase(next,hold||3000);
 }
 function returnToIdle(hold=0){interactionAction=null;forcedState=null;forcedUntil=0;path=[];velocity={x:0,y:0};setPhase('idle',hold||profile().pause+700)}
 function planPark(){
  if(!field?.points.length||!position)return false;
  // Legacy action name is retained for callers, but the right resting place
  // stays on the same physical floor; it never climbs back through content.
  const target={x:box.right-profile().w/2-12,y:field.groundY};
  const candidates=field.points.map((p,i)=>({i,d:PET_MOTION_MATH.distance(p,target)})).sort((a,b)=>a.d-b.d);
  for(const c of candidates){const planned=PET_MOTION_MATH.path(field,position,c.i);if(!planned.length)continue;
   const end=planned[planned.length-1];
   if(PET_MOTION_MATH.distance(position,end)<8){parkIntent=false;parkedUntil=now()+20000;startInteraction('upper-right',20000);return true}
   path=planned;interactionAction=null;setPhase('walk');return true;
  }
  parkIntent=false;returnToIdle(2000);return false;
 }
 // A navigation climb needs verified paw-by-paw footage/frames. Until that
 // exists, keep the companion on its floor instead of sliding an image up.
 function planPeek(){peekIntent=false;return false}
 function beginPeek(){peekIntent=false;peekArrivalPending=false;peekStartedAt=0;peekOffset=0;if(!sleeping())returnToIdle(1200)}
 function animatePeek(){beginPeek()}
 function chooseAutonomous(t){
  const p=currentPet();if(parkIntent)return planPark();
  if(parkedUntil>t||t-lastAutoStart<8000)return false;
  const started=ok=>{if(ok)lastAutoStart=t;return ok};
  const fed=(p?.foodLevel??70)>25,hydrated=(p?.waterLevel??70)>25;
  if(fed&&hydrated&&Math.random()<.23){const toys=['ball','fish'].filter(hasInteraction);if(toys.length){startInteraction(toys[Math.floor(Math.random()*toys.length)]);return started(true)}}
  const hour=new Date().getHours(),sleepy=hour>=22||hour<7||(p?.mood??70)<45||(p?.foodLevel??70)<40;
  if(sleepy&&hasInteraction('sleep')&&t-lastWakeAt>=180000&&Math.random()<.12){beginNap('autonomous');return started(true)}
  if(hasContinuousAction('groom')&&Math.random()<.15){startInteraction('groom');return started(true)}
  return started(choosePath());
 }
 function stopAnimated(){
  imageGeneration++;imageActive=false;imagePending=false;imageStartedAt=0;imageDeadline=0;imageSettled=false;imagePoster=null;settledPoseUntil=0;
  if(animated){animated.onload=null;animated.onerror=null;animated.hidden=true;animated.removeAttribute('src')}
  if(imageObjectURL){URL.revokeObjectURL(imageObjectURL);imageObjectURL=null}
 }
 function fetchImageBlob(src){
  if(typeof fetch!=='function'||typeof URL.createObjectURL!=='function')return Promise.resolve(null);
  if(!imageBlobCache.has(src))imageBlobCache.set(src,fetch(src,{cache:'force-cache',credentials:'same-origin'}).then(r=>r.ok?r.blob():null).catch(()=>null));
  return imageBlobCache.get(src);
 }
 function startAnimated(clip){
  const generation=++imageGeneration;imagePending=true;imageSettled=false;
  if(phase==='sleep'&&sleepHoldPose&&clip.endPoster){animated.onload=()=>{if(generation!==imageGeneration||activeClip!==clip||blocked()||!enabled())return;imagePending=false;imageActive=true;imageSettled=true;imageDeadline=0;animated.hidden=false;sprite.hidden=true;canvas.hidden=true;finishVisualTransition();renderSource='alpha-poster';layer.dataset.render='alpha-poster';layer.dataset.asleep='true'};animated.onerror=()=>{if(generation===imageGeneration){motionFallback='sleep-poster-load-error';showStill()}};animated.src=clip.endPoster;return}

  // A fresh object URL gives each one-shot its own decoder, without refetching bytes.
  fetchImageBlob(clip.src).then(blob=>{
   if(generation!==imageGeneration||activeClip!==clip||!enabled()||blocked()||layer?.hidden)return;
   const url=blob?URL.createObjectURL(blob):clip.src+'#pm-replay-'+generation;
   if(blob)imageObjectURL=url;
   animated.onload=()=>{
    if(generation!==imageGeneration||activeClip!==clip||blocked()||!enabled()||layer?.hidden)return;
    imagePending=false;imageActive=true;imageStartedAt=now();imageDeadline=clip.loopSafe||!clip.durationMs?0:imageStartedAt+clip.durationMs;
    animated.hidden=false;sprite.hidden=true;canvas.hidden=true;renderSource='animated-image';layer.dataset.render='animated-image';layer.dataset.asleep=clip.depictsSleep?'true':'false';motionFallback=null;
   };
   animated.onerror=()=>{if(generation!==imageGeneration)return;failedClips.add(clip.src);clipKey=null;motionFallback='animated-image-load-error';showStill()};
   animated.style.transform='none';animated.src=url;
  });
 }
 function settleAnimated(clip){
  if(!imageActive||imageSettled)return;imageSettled=true;imageDeadline=0;
  if(clip.endPoster){
   const generation=imageGeneration,poster=new Image();imagePoster=poster;
   poster.onload=()=>{if(generation!==imageGeneration||activeClip!==clip||!imageSettled||blocked()||!enabled())return;animated.onload=null;animated.onerror=null;animated.src=clip.endPoster;renderSource='alpha-poster';layer.dataset.render='alpha-poster';if(imageObjectURL){URL.revokeObjectURL(imageObjectURL);imageObjectURL=null}};
   poster.onerror=()=>{if(generation===imageGeneration&&clip.loopCount!==1){motionFallback='one-shot-poster-load-error';showStill()}};poster.src=clip.endPoster;
  }else if(clip.loopCount!==1&&clip.animationLoops!==1){motionFallback='one-shot-poster-missing';showStill()}
 }
 function finishOneShot(t){
  if(!activeClip||activeClip.loopSafe||!activeClip.durationMs)return;
  const action=interactionAction||activeClip.state;
  if(action==='reluctant'){resumeSleepPose();return}
  if(action==='sleep'||action==='upper-right'||action==='sit'||action==='peek'){
   if(action==='sleep')sleepHoldPose=true;
   if(activeClip.kind==='animated-image')settleAnimated(activeClip);else{video.pause();cancelNativeVideoFrame();imageSettled=true}
   imageDeadline=0;if(action==='upper-right'||action==='sit')phaseUntil=Math.max(phaseUntil,parkedUntil||t+12000);return;
  }
  if(action==='walk'&&peekArrivalPending){beginPeek();return}
  if(action==='walk'&&parkArrivalPending){parkArrivalPending=false;parkIntent=false;parkedUntil=t+20000;startInteraction('upper-right',20000);return}
  if(activeClip.interaction||['feed','treat','snack','whip','teaser','ball','fish','wake','groom','climb'].includes(action)){
   if(activeClip.kind!=='animated-image'){video.pause();cancelNativeVideoFrame()}
   settledPoseUntil=0;returnToIdle(8500+Math.random()*4500);clipKey=null;return;
  }
  if(activeClip.state==='walk'||activeClip.state==='play'){
   path=[];velocity={x:0,y:0};interactionAction=null;forcedState=null;forcedUntil=0;
   setPhase(currentPet()?.behavior==='sleep'?'sleep':'idle',parkIntent||peekIntent?800:profile().pause+800);clipKey=null;
  }else if(activeClip.kind==='animated-image')settleAnimated(activeClip);
  else{video.pause();cancelNativeVideoFrame();imageSettled=true;imageDeadline=0}
 }
 function keepPreviousFrame(){
  cancelNativeVideoFrame();if(video&&!video.paused)video.pause();
  transitionSerial++;transitionPending=true;
  if(transitionCanvas&&transitionCtx){
   const p=profile(),w=Math.round(p.w*2),h=Math.round(p.h*2);transitionCanvas.width=w;transitionCanvas.height=h;transitionCtx.clearRect(0,0,w,h);
   if(canvas&&!canvas.hidden)transitionCtx.drawImage(canvas,0,0,w,h);
   else if(animated&&!animated.hidden&&animated.naturalWidth){const scale=Math.min(w/animated.naturalWidth,h/animated.naturalHeight),dw=animated.naturalWidth*scale,dh=animated.naturalHeight*scale;transitionCtx.drawImage(animated,(w-dw)/2,h-dh,dw,dh)}
   transitionCanvas.hidden=false;transitionCanvas.style.opacity='1';
  }
  imageGeneration++;imageActive=false;imagePending=false;imageSettled=false;imageDeadline=0;imagePoster=null;settledPoseUntil=0;if(animated){animated.onload=null;animated.onerror=null}
 }
 function finishVisualTransition(){
  if(!transitionPending)return;transitionPending=false;const serial=transitionSerial;
  if(transitionCanvas){transitionCanvas.style.opacity='0';setTimeout(()=>{if(serial===transitionSerial&&transitionCanvas)transitionCanvas.hidden=true},230)}
 }
 function showStill(){transitionSerial++;transitionPending=false;if(transitionCanvas)transitionCanvas.hidden=true;cancelNativeVideoFrame();stopAnimated();renderSource='still';if(layer){layer.dataset.render='still';layer.dataset.asleep='false';delete layer.dataset.action;delete layer.dataset.actionFrame}if(canvas)canvas.hidden=true;if(sprite)sprite.hidden=false;if(video&&!video.paused)video.pause();}
 function cancelNativeVideoFrame(){if(videoFrameHandle!==null&&video?.cancelVideoFrameCallback)video.cancelVideoFrameCallback(videoFrameHandle);videoFrameHandle=null}
 function scheduleNativeVideoFrame(){
  if(videoFrameHandle!==null||!video?.requestVideoFrameCallback||activeClip?.kind!=='alpha-video'||video.paused||imageSettled||!enabled()||blocked()||layer?.hidden)return;
  videoFrameHandle=video.requestVideoFrameCallback((t,metadata)=>{videoFrameHandle=null;if(activeClip?.kind==='alpha-video'&&!video.paused&&!imageSettled&&enabled()&&!blocked()&&!layer?.hidden){drawAlphaVideo(t);presentedVideoFrames=metadata?.presentedFrames||presentedVideoFrames+1;if(layer)layer.dataset.videoFrame=String(presentedVideoFrames);scheduleNativeVideoFrame()}});
 }
 function startMedia(){
  if(!video||mediaFailed||!activeClip||activeClip.kind==='animated-image'||imageSettled||phase==='sleep'&&sleepHoldPose||!enabled()||blocked()||layer?.hidden)return;
  const attempt=video.play();if(attempt&&typeof attempt.then==='function')attempt.then(scheduleNativeVideoFrame).catch(()=>{mediaPending=true;showStill()});else scheduleNativeVideoFrame();
 }
 function holdVideoSleepPoster(clip){
  const generation=++imageGeneration;imagePending=true;imageSettled=false;
  animated.onload=()=>{if(generation!==imageGeneration||activeClip!==clip||blocked()||!enabled())return;imagePending=false;imageActive=true;imageSettled=true;imageDeadline=0;animated.hidden=false;sprite.hidden=true;canvas.hidden=true;finishVisualTransition();renderSource='alpha-poster';layer.dataset.render='alpha-poster';layer.dataset.asleep='true'};
  animated.onerror=()=>{if(generation===imageGeneration){motionFallback='sleep-poster-load-error';showStill()}};animated.src=clip.endPoster;
 }
 function resolveAtlas(){return null} // Do not slide sparse/still pose cycles as natural motion.
 function getAtlas(meta){
  let entry=atlasCache.get(meta.src);if(entry)return entry;
  entry={image:new Image(),ready:false,failed:false};atlasCache.set(meta.src,entry);
  entry.image.onload=()=>{const image=entry.image,ratio=(image.naturalWidth/meta.columns)/(image.naturalHeight/meta.rows);entry.ready=(!meta.generatedAction||(!meta.width||meta.width===image.naturalWidth)&&(!meta.height||meta.height===image.naturalHeight))&&image.naturalWidth>=meta.columns*24&&image.naturalHeight>=meta.rows*24&&ratio>=.4&&ratio<=3;if(!entry.ready){entry.failed=true;motionFallback='invalid-atlas-dimensions'}};
  entry.image.onerror=()=>{entry.failed=true;motionFallback='atlas-load-error'};entry.image.src=meta.src;return entry;
 }
 function syncMedia(){
  if(imageSettled&&activeClip?.interaction&&phase==='idle'&&now()<settledPoseUntil)return;
  const actionAtlas=generatedAction();const clip=actionAtlas?null:resolveClip();const usableClip=clip&&!failedClips.has(clip.src)?clip:null;
  const atlas=actionAtlas||(usableClip?null:resolveAtlas());
  const key=usableClip?usableClip.kind+':'+usableClip.src+':'+usableClip.state:atlas?(atlas.generatedAction?'action-atlas:':'atlas:')+atlas.src+':'+atlas.row+':'+phase:'';
  if(key===clipKey)return;const keep=usableClip?.kind==='alpha-video'&&((canvas&&!canvas.hidden)||(animated&&!animated.hidden))&&['alpha-video','alpha-poster','animated-image'].includes(renderSource);clipKey=key;activeClip=usableClip;atlasMeta=atlas;atlasEntry=null;mediaFailed=false;if(keep)keepPreviousFrame();else showStill();
  if(atlas){atlasStartedAt=atlas.generatedAction?0:now();actionAtlasHoldUntil=0;actionAtlasLastFrame=-1;atlasEntry=getAtlas(atlas);if(atlas.action==='climb'){sprite.hidden=true;canvas.hidden=true;}motionFallback=atlasEntry.failed?'atlas-load-error':atlasEntry.ready?null:'atlas-loading';return}
  if(!usableClip){motionFallback=clip?'video-load-error':null;return}
  motionFallback=null;if(phase==='sleep'&&sleepHoldPose&&usableClip.kind==='alpha-video'&&usableClip.endPoster){holdVideoSleepPoster(usableClip);return}if(usableClip.kind==='animated-image'){startAnimated(usableClip);return}video.src=usableClip.src;video.loop=usableClip.loopSafe===true;video.load();mediaPending=true;if(phase==='climb'){sprite.hidden=true;canvas.hidden=true}startMedia();
 }
 function drawActionAtlas(t){
  const meta=atlasMeta;if(!meta?.generatedAction||!atlasEntry?.ready||atlasEntry.failed)return;
  if(!atlasStartedAt)atlasStartedAt=t;
  const elapsed=Math.max(0,t-atlasStartedAt),end=elapsed>=meta.durationMs;
  if(end&&!actionAtlasHoldUntil)actionAtlasHoldUntil=atlasStartedAt+meta.durationMs+meta.holdMs;
  if(actionAtlasHoldUntil&&t>=actionAtlasHoldUntil){atlasMeta=null;atlasEntry=null;clipKey=null;actionAtlasHoldUntil=0;returnToIdle(8500+Math.random()*3500);return}
  const index=Math.min(meta.frameCount-1,Math.floor(elapsed/meta.durationMs*meta.frameCount));if(actionAtlasLastFrame===index)return;actionAtlasLastFrame=index;lastDraw=t;
  const r=meta.frameRects[index],crop=meta.sourceCrop||{x:0,y:0,width:r.width,height:r.height},p=profile();
  const cw=Math.round(p.w*2),ch=Math.round(p.h*2);if(canvas.width!==cw||canvas.height!==ch){canvas.width=cw;canvas.height=ch}
  const anchor=meta.frameAnchors?.[index]||{x:crop.width*meta.anchor.x,y:crop.height*meta.anchor.y};
  const scale=meta.action==='climb'?ch/(meta.bodyReferenceHeight||265):Math.min(cw/crop.width,ch/anchor.y),dx=cw/2-anchor.x*scale,dy=ch-anchor.y*scale;
  ctx.clearRect(0,0,cw,ch);ctx.drawImage(atlasEntry.image,r.x+crop.x,r.y+crop.y,crop.width,crop.height,dx,dy,crop.width*scale,crop.height*scale);
  canvas.style.transform='none';canvas.hidden=false;sprite.hidden=true;renderSource='generated-action-atlas';layer.dataset.render=renderSource;layer.dataset.actionFrame=String(index);layer.dataset.action=meta.action;layer.dataset.asleep='false';motionFallback=null;
 }
 function drawAtlas(t){
  if(atlasMeta?.generatedAction)return drawActionAtlas(t);
  if(!atlasMeta||!atlasEntry||atlasEntry.failed||!atlasEntry.ready||t-lastDraw<1000/atlasMeta.fps)return;
  if(canvas.width!==168||canvas.height!==168){canvas.width=168;canvas.height=168}const image=atlasEntry.image,cols=atlasMeta.columns,rows=atlasMeta.rows,w=image.naturalWidth/cols,h=image.naturalHeight/rows;
  if(!w||!h)return;lastDraw=t;
  const frameIndex=Math.floor((t-atlasStartedAt)/1000*atlasMeta.fps)%cols;const scale=Math.min(158/w,158/h),dw=w*scale,dh=h*scale;
  ctx.clearRect(0,0,168,168);ctx.drawImage(image,frameIndex*w,atlasMeta.row*h,w,h,(168-dw)/2,166-dh,dw,dh);
  const sign=Math.abs(velocity.x)>1?(atlasMeta.facing==='right'?Math.sign(velocity.x):-Math.sign(velocity.x)):1;
  canvas.style.transform=sign<0?'scaleX(-1)':'none';canvas.hidden=false;sprite.hidden=true;renderSource='atlas';layer.dataset.render='atlas';motionFallback=null;
 }
 function drawAlphaVideo(t){
  const clip=activeClip;if(!clip||clip.kind!=='alpha-video'||mediaFailed||!video||video.paused||video.readyState<2||imageSettled)return;
  const w=clip.contentWidth,h=clip.contentHeight;
  if(video.videoWidth!==w*2||video.videoHeight!==h){mediaFailed=true;failedClips.add(clip.src);motionFallback='packed-alpha-dimensions';showStill();return}
  try{
   const p=profile(),dpr=PET_MOTION_MATH.clamp(window.devicePixelRatio||2,1,2),cw=Math.round(p.w*dpr),ch=Math.round(p.h*dpr),scale=Math.min(cw/w,ch/h),rw=Math.max(1,Math.round(w*scale)),rh=Math.max(1,Math.round(h*scale));
   if(canvas.width!==cw||canvas.height!==ch){canvas.width=cw;canvas.height=ch}if(rawCanvas.width!==rw*2||rawCanvas.height!==rh){rawCanvas.width=rw*2;rawCanvas.height=rh}
   rawCtx.clearRect(0,0,rw*2,rh);rawCtx.drawImage(video,0,0,w*2,h,0,0,rw*2,rh);
   const rgb=rawCtx.getImageData(0,0,rw,rh),mask=rawCtx.getImageData(rw,0,rw,rh);PET_MOTION_MATH.combineAlpha(rgb,mask);rawCtx.putImageData(rgb,0,0);
   const padding=(Number(clip.groundPaddingPx)||0)*scale;ctx.clearRect(0,0,cw,ch);ctx.drawImage(rawCanvas,0,0,rw,rh,(cw-rw)/2,ch-rh+padding,rw,rh);
   const facing=clip.facing,side=facing==='left'||facing==='right';canvas.style.transform=side&&Math.abs(velocity.x)>1&&(facing==='right'?velocity.x<0:velocity.x>0)?'scaleX(-1)':'none';canvas.hidden=false;sprite.hidden=true;animated.hidden=true;finishVisualTransition();renderSource='alpha-video';layer.dataset.render='alpha-video';layer.dataset.nativeFps=String(clip.fps||'native');layer.dataset.asleep=clip.depictsSleep?'true':'false';mediaTick=t;
  }catch{mediaFailed=true;failedClips.add(clip.src);motionFallback='packed-alpha-render-error';showStill()}
 }
 function keyWhite(image){const data=image.data,w=image.width,h=image.height,visited=new Uint8Array(w*h),queue=new Int32Array(w*h);let head=0,tail=0;const isWhite=i=>{const p=i*4,r=data[p],g=data[p+1],b=data[p+2];return Math.min(r,g,b)>232&&Math.max(r,g,b)-Math.min(r,g,b)<27};const push=i=>{if(i<0||i>=w*h||visited[i]||!isWhite(i))return;visited[i]=1;queue[tail++]=i};for(let x=0;x<w;x++){push(x);push((h-1)*w+x)}for(let y=0;y<h;y++){push(y*w);push(y*w+w-1)}while(head<tail){const i=queue[head++];data[i*4+3]=0;const x=i%w;if(x>0)push(i-1);if(x<w-1)push(i+1);if(i>=w)push(i-w);if(i<w*(h-1))push(i+w)}let left=w,top=h,right=0,bottom=0;for(let i=0;i<w*h;i++){if(data[i*4+3]>16){const x=i%w,y=Math.floor(i/w);if(x<left)left=x;if(x>right)right=x;if(y<top)top=y;if(y>bottom)bottom=y}}return left>right?null:{left,top,width:right-left+1,height:bottom-top+1};}
 function drawVideo(t){if(activeClip?.kind==='alpha-video'){if(video?.requestVideoFrameCallback)scheduleNativeVideoFrame();else drawAlphaVideo(t);return}if(canvas&&(canvas.width!==168||canvas.height!==168)){canvas.width=168;canvas.height=168}if(!activeClip||activeClip.kind==='animated-image'||mediaFailed||!video||video.paused||video.readyState<2||t-lastDraw<1000/(phase==='idle'||phase==='sleep'?12:MAX_VIDEO_FPS))return;lastDraw=t;const vw=video.videoWidth,vh=video.videoHeight;if(!vw||!vh)return;const rawW=160,rawH=Math.max(64,Math.round(rawW*vh/vw));if(rawH>320)return;try{if(rawCanvas.width!==rawW||rawCanvas.height!==rawH){rawCanvas.width=rawW;rawCanvas.height=rawH}rawCtx.clearRect(0,0,rawW,rawH);rawCtx.drawImage(video,0,0,rawW,rawH);let bounds={left:0,top:0,width:rawW,height:rawH};if(activeClip.keyWhite!==false){const pixels=rawCtx.getImageData(0,0,rawW,rawH);bounds=keyWhite(pixels);if(!bounds)return;rawCtx.putImageData(pixels,0,0)}ctx.clearRect(0,0,168,168);const scale=Math.min(158/bounds.width,158/bounds.height),w=bounds.width*scale,h=bounds.height*scale;ctx.drawImage(rawCanvas,bounds.left,bounds.top,bounds.width,bounds.height,(168-w)/2,166-h,w,h);canvas.hidden=false;sprite.hidden=true;renderSource='video';layer.dataset.render='video';layer.dataset.asleep=activeClip.depictsSleep?'true':'false';const side=activeClip.facing==='left'||activeClip.facing==='right';const sign=side&&Math.abs(velocity.x)>1?(activeClip.facing==='right'?Math.sign(velocity.x):-Math.sign(velocity.x)):1;canvas.style.transform=sign<0?'scaleX(-1)':'none';mediaTick=t;}catch{mediaFailed=true;showStill()}}
 function place(){if(!actor||!position||!box)return;const p=profile();position.y=field.groundY;velocity.y=0;layer.dataset.footY=(position.y+p.h/2).toFixed(2);layer.dataset.grounded='true';const transform=`translate3d(${(position.x-box.left-p.w/2).toFixed(2)}px,${(position.y-box.top-p.h/2).toFixed(2)}px,0)`;if(actor.style.transform!==transform)actor.style.transform=transform;actor.style.setProperty('--pm-speed',Math.hypot(velocity.x,velocity.y).toFixed(2));}
 function moveAlongPath(t,dt){
  if(!path.length)return;
  const target=path[0],dist=PET_MOTION_MATH.distance(position,target);
  if(dist<6){
   path.shift();
   if(!path.length){
    if(peekIntent){const pending=activeClip&&!activeClip.loopSafe&&(imageDeadline>t||activeClip.kind==='video'&&!video.ended&&!video.paused);if(pending){peekArrivalPending=true;velocity={x:0,y:0}}else beginPeek();return}
    if(parkIntent){const pending=activeClip&&!activeClip.loopSafe&&(imageDeadline>t||activeClip.kind==='video'&&!video.ended&&!video.paused);if(pending){parkArrivalPending=true;velocity={x:0,y:0}}else{parkIntent=false;parkedUntil=t+20000;startInteraction('upper-right',20000)}return}
    const oneShot=activeClip&&!activeClip.loopSafe&&(imageDeadline>t||activeClip.kind==='video'&&!video.ended&&!video.paused);
    if(oneShot){if(!choosePath()){velocity={x:0,y:0};phaseUntil=imageDeadline||t+500}}
    else{returnToIdle(profile().pause+Math.random()*2000)}
   }
   return;
  }
  const config=profile(),mediaReady=activeClip?.kind!=='animated-image'||imageActive;
  const remaining=imageDeadline?Math.max(0,imageDeadline-t):activeClip?.kind==='video'&&!activeClip.loopSafe&&Number.isFinite(video.duration)?Math.max(0,(video.duration-video.currentTime)*1000):Infinity;
  const settleFactor=Number.isFinite(remaining)?Math.min(1,remaining/240):1;
  const speed=mediaReady?(stage()===0&&t%6000<1400?config.burst:config.speed)*Math.min(1,Math.max(.25,dist/26))*settleFactor:0;
  const next=PET_MOTION_MATH.steer(position,velocity,{x:target.x,y:field.groundY},speed,dt);next.position.y=field.groundY;next.velocity.y=0;
  if(PET_MOTION_MATH.segmentClear(position,next.position,box,field.obstacles,field.padX,field.padY)){position=next.position;velocity=next.velocity}
  else{path=[];velocity={x:0,y:0};interactionAction=null;setPhase('idle',900);dirty=true}
 }
 function tick(t){
  frame=0;if(!enabled()||blocked()){hide();return}
  if(!lastFrame){lastFrame=t;lastDraw=0}
  const playingVideo=activeClip&&activeClip.kind!=='animated-image'&&!video?.paused&&!imageSettled;
  const busy=['walk','play','teaser','ball','fish','peek','groom','climb'].includes(phase),frameRate=playingVideo?Math.max(30,Math.min(60,activeClip.fps||60)):atlasMeta?.generatedAction&&actionAtlasHoldUntil>t?8:busy?FPS:activeClip&&!imageSettled?12:8;
  if(t-lastFrame<1000/frameRate-.5){frame=requestAnimationFrame(tick);return}
  const elapsed=t-lastFrame,dt=Math.min(.065,elapsed/1000),interval=1000/frameRate;lastFrame+=Math.max(1,Math.floor((elapsed+.5)/interval))*interval;
  if(dirty&&!readGeometry())return;if(!box||!position)return;layer.hidden=false;
  if(imageDeadline&&t>=imageDeadline)finishOneShot(t);
  const p=currentPet();
  if(p?.behavior==='sleep'&&!napKind)beginNap('manual');
  if(napKind){
   path=[];velocity={x:0,y:0};
   if(t>=autoNapUntil)finishNap();
   else if(phase!=='sleep'&&phase!=='reluctant')resumeSleepPose();
  }else if(phase==='sleep'||phase==='reluctant')finishNap();
  const stationary=['feed','treat','snack','whip','teaser','ball','fish','wake','play','sit','reluctant','groom','climb'].includes(phase);
  if(phase==='walk')moveAlongPath(t,dt);
  else if(phase==='peek')animatePeek(t);
  else if(stationary){
   path=[];velocity={x:0,y:0};
   const playing=!!atlasMeta?.generatedAction||(imageActive&&!imageSettled&&!!imageDeadline)||imagePending||(activeClip?.kind==='video'&&!video.paused&&!video.ended);
   if(!playing&&t>=phaseUntil){if(phase==='reluctant')resumeSleepPose();else{parkedUntil=0;returnToIdle(800)}}
  }else if(phase==='idle'&&t>=phaseUntil){
   if(!chooseAutonomous(t))setPhase('idle',2000+Math.random()*2200);
  }
  syncMedia();if(atlasMeta)drawAtlas(t);else if(activeClip?.kind!=='animated-image')drawVideo(t);
  if(animated&&imageActive){const facing=activeClip?.facing,side=facing==='left'||facing==='right',p=profile(),padding=Number(activeClip?.groundPaddingPx)||0,scale=activeClip?.width&&activeClip?.height?Math.min(p.w/activeClip.width,p.h/activeClip.height):0;const align=padding>0?'translateY('+(padding*scale).toFixed(2)+'px)':'';const flip=side&&Math.abs(velocity.x)>1&&(facing==='right'?velocity.x<0:velocity.x>0)?' scaleX(-1)':'';animated.style.transform=(align+flip).trim()||'none'}
  syncWakeUi(t);place();
  frame=requestAnimationFrame(tick);
 }
 function update(){
  if(!initialized)return init();removeLegacyMotionUi();
  if(!adopted()){hide();return}
  if(napKind&&now()>=autoNapUntil)finishNap();
  createLayer();route=location.hash.slice(1).split('/')[0]||'home';const app=document.querySelector('.phone #app');
  if(!app){hide();return}
  if(['welcome','pet-select','petselect','placement','test-level'].includes(route)){hide();return}
  visual();dirty=true;if(!enabled()||blocked()){hide();return}
  restoreStage();if(readGeometry()){
   layer.hidden=false;if(!climbEntryDone&&!scene&&!sleeping()&&hasContinuousAction('climb')){climbEntryDone=true;startInteraction('climb');sprite.hidden=true;canvas.hidden=true;syncMedia()}syncWakeUi(now());if(parkIntent&&!path.length&&phase==='idle'&&now()>=phaseUntil)planPark();if(peekIntent&&!path.length&&phase==='idle'&&now()>=phaseUntil)planPeek();place();startMedia();if(!frame)frame=requestAnimationFrame(tick);
  }
 }
 function geometryChanged(){dirty=true;if(!blocked()&&enabled()&&!frame)update()}
 function init(){if(initialized)return update();initialized=true;S.petSettings=S.petSettings||{};if(typeof S.petSettings.roaming!=='boolean')S.petSettings.roaming=true;reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)');const reducedChange=()=>update();if(reduced?.addEventListener){reduced.addEventListener('change',reducedChange);cleanup.push(()=>reduced.removeEventListener('change',reducedChange))}listen(window,'resize',geometryChanged,{passive:true});listen(window,'scroll',geometryChanged,{passive:true,capture:true});listen(document,'visibilitychange',()=>document.hidden?hide():update());listen(document,'focusin',()=>{if(typing())hide()});listen(document,'focusout',()=>setTimeout(update,100));listen(window,'pointerdown',()=>{if(mediaPending&&enabled()&&!blocked()){mediaPending=false;startMedia()}},{passive:true});listen(window,'pagehide',hide);listen(window,'online',()=>{failedClips.clear();atlasCache.clear();imageBlobCache.clear();clipKey=null;update()});if(typeof ResizeObserver!=='undefined'){resizeObserver=new ResizeObserver(geometryChanged);const phoneEl=document.querySelector('.phone');if(phoneEl)resizeObserver.observe(phoneEl)}if(typeof MutationObserver!=='undefined'){dialogObserver=new MutationObserver(()=>blocked()?hide():update());const modalEl=document.querySelector('#modal');if(modalEl)dialogObserver.observe(modalEl,{attributes:true,attributeFilter:['open']})}update();}
 function react(action){
  if(['record-charge','record-run'].includes(action))return false;
  if(!initialized)init();if(!adopted())return false;
  const allowed=['feed','treat','snack','whip','teaser','ball','fish','rest','wake','play','upper-right','peek','nav-entry','groom','climb'];if(!allowed.includes(action))return false;
  if(action==='climb'||action==='peek'||action==='nav-entry'){if(!sleeping()&&hasContinuousAction('climb')){clearNap('climb');climbEntryDone=true;startInteraction('climb');sprite.hidden=true;canvas.hidden=true;update();syncMedia();return true}peekIntent=false;peekArrivalPending=false;peekStartedAt=0;peekOffset=0;if(!sleeping())returnToIdle(1200);update();return false}
  if(action==='groom'&&!hasContinuousAction('groom'))return false;
  if(action==='wake'||action==='rest'&&(napKind||phase==='sleep'||phase==='reluctant')){return requestWake('call')}
  if(action==='rest'){beginNap('manual');update();return true}
  clearNap('care-interaction');parkArrivalPending=false;parkedUntil=0;peekIntent=false;peekArrivalPending=false;peekStartedAt=0;peekOffset=0;
  if(action==='upper-right'){
   parkIntent=true;interactionAction=null;path=[];velocity={x:0,y:0};setPhase('idle',0);update();if(enabled()&&!blocked()&&parkIntent&&!path.length&&phase==='idle')planPark();return true;
  }
  parkIntent=false;
  startInteraction(action,action==='feed'?5000:4300);
  update();return true;
 }
 function destroy(){stop();restoreStage();resizeObserver?.disconnect();dialogObserver?.disconnect();cleanup.forEach(fn=>fn());cleanup=[];if(video){video.removeAttribute('src');video.load()}layer?.remove();removeLegacyMotionUi();transitionSerial++;transitionPending=false;transitionCanvas=transitionCtx=null;layer=actor=video=animated=wakeTouch=wakeBubble=null;initialized=false;position=null;field=null;peekIntent=false;peekArrivalPending=false;peekStartedAt=0;peekOffset=0;interactionAction=null;autoNapUntil=0;napKind=null;wakeRequests=0;wakeRequestedAt=0;wakeBubbleUntil=0;sleepHoldPose=false;lastWakeAt=-Infinity;parkIntent=false;parkedUntil=0;visualKey='';clipKey='';atlasMeta=null;atlasEntry=null;actionAtlasHoldUntil=0;actionAtlasLastFrame=-1;lastAutoStart=-Infinity;climbEntryDone=false;atlasCache.clear();imageBlobCache.clear();failedClips.clear();clipVariantCache.clear();clipVariantCounters.clear();}
 function state(){return {initialized,transitionPending,videoFrameCallbackActive:videoFrameHandle!==null,presentedVideoFrames,sleeping:sleeping(),napKind,napUntil:autoNapUntil,wakeRequests,wakeBubbleUntil,sleepHoldPose,lastAutonomousStart:lastAutoStart,nextAutonomousDecisionAt:phaseUntil,phase,interactionAction,parking:parkIntent,parkArrivalPending,parkedUntil,peekIntent,peekArrivalPending,peekOffset,peekDuration,navEdgeY,floorY:field?.floorY??null,grounded:!!position&&!!field&&Math.abs(position.y-field.groundY)<.01,surface:scene?'room-floor':'navigation-edge',actorSize:{width:profile().w,height:profile().h},autonomousNapUntil:autoNapUntil,position:position?{...position}:null,velocity:{...velocity},visible:!!layer&&!layer.hidden,videoActive:!!video&&!video.paused,animatedImageActive:imageActive&&!imageSettled,transparentImageVisible:imageActive,animatedImagePending:imagePending,oneShotSettled:imageSettled,clip:activeClip?.src||null,route,usingScene:!!scene,renderSource,atlas:atlasMeta?{src:atlasMeta.src,row:atlasMeta.row,columns:atlasMeta.columns,fps:atlasMeta.fps,action:atlasMeta.action,frameCount:atlasMeta.frameCount,startedAt:atlasStartedAt,holdUntil:actionAtlasHoldUntil,generatedAction:!!atlasMeta.generatedAction}:null,motionFallback}}
 function capabilities(){return {breed:currentPet()?.breed,type:currentPet()?.type,stage:stage(),interactionActions:['feed','treat','snack','whip','teaser','ball','fish','walk','sleep','wake','upper-right','peek','play','groom','climb','reluctant'].filter(hasInteraction)}}
 return {init,update,react,requestWake,destroy,state,capabilities};
})();
function initPetMotion(){return PetMotion.init()}
function updatePetMotion(){return PetMotion.update()}
function petMotionReact(action){return PetMotion.react(action)}
function destroyPetMotion(){return PetMotion.destroy()}
function getPetMotionState(){return PetMotion.state()}

function getPetMotionCapabilities(){return PetMotion.capabilities()}

function requestPetWake(source='touch'){return PetMotion.requestWake(source)}
function callPetWake(){return PetMotion.requestWake('call')}
