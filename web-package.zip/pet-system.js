'use strict';
// Companion data lives inside the existing profile; no progress key is replaced.
const PET_BREEDS=[
 {name:'Рыжий табби',hint:'Тёплый и любопытный'},
 {name:'Британская голубая',hint:'Спокойный наблюдатель'},
 {name:'Биколор',hint:'Пушистый исследователь'},
 {name:'Рэгдолл',hint:'Ласковый напарник'},
 {name:'Серебристый табби',hint:'Любит новые открытия'},
 {name:'Сиамская',hint:'Общительный характер'},
 {name:'Золотая длинношёрстная',hint:'Маленькое солнышко'},
 {name:'Серо-белая',hint:'Уютный компаньон'},
 {name:'Белая персидская',hint:'Облачко спокойствия'},
 {name:'Бенгальская',hint:'Энергия и любопытство'},
 {name:'Русская голубая',hint:'Внимательный друг'},
 {name:'Абиссинская',hint:'Всегда готов к игре'},
 {name:'Колор-пойнт',hint:'Мягкий и пушистый'},
 {name:'Сибирская',hint:'Большое доброе сердце'},
 {name:'Белая голубоглазая',hint:'Снежный напарник'},
 {name:'Девон-рекс',hint:'Ушастый исследователь'}
];
const PET_SCENES=[
 {id:'jade',name:'Нефритовый сад',cn:'竹园',emoji:'🎋',desc:'Свежая зелень и мягкий свет'},
 {id:'paper',name:'Светлая студия',cn:'书房',emoji:'📚',desc:'Бумага, книги и спокойные оттенки'},
 {id:'tea',name:'Чайная комната',cn:'茶室',emoji:'🍵',desc:'Тёплое дерево и уют'},
 {id:'night',name:'Вечерний Шанхай',cn:'夜色',emoji:'🌙',desc:'Синий вечер и свет фонарей'}
];
const PS_POSITIONS=[{label:'Слева у стены',x:14,y:45},{label:'У окна',x:46,y:37},{label:'Справа у стены',x:79,y:43},{label:'Слева на полу',x:17,y:72},{label:'В центре',x:50,y:76},{label:'Справа на полу',x:82,y:73}];
const PS_FURNITURE=[
 {id:'shelf',name:'Моя книжная полка',icon:'▥',need:0,slot:2,kind:'books'},
 {id:'plant',name:'Зелёное растение',icon:'🪴',item:'plant',slot:0},
 {id:'lamp',name:'Китайский фонарик',icon:'🏮',item:'lamp',slot:1},
 {id:'house',name:'Маленький домик',icon:'⛺',item:'house',slot:5},
 {id:'teaser',name:'Удочка-дразнилка',icon:'🪶',need:30,slot:3},
 {id:'tower',name:'Когтеточка',icon:'🪜',need:80,slot:0},
 {id:'bed',name:'Мягкая лежанка',icon:'🧺',need:150,slot:5}
];
let petDraft={type:'cat',breed:4,catBreed:4,gender:'female',name:''};
let petFurnitureSelected='shelf';
let petSystemInitialized=false;
const petClamp=(value,min=0,max=100)=>Math.max(min,Math.min(max,Number.isFinite(value)?value:min));
function normalizePetState(){
 const now=Date.now();let raw=S.petState;
 if(!raw||typeof raw!=='object'||Array.isArray(raw))raw={};
 const initialXp=(new Set([...(S.completed||[]),...(S.workbookDone||[])]).size)*30;
 const isDog=raw.type==='dog'&&raw.breed==='corgi';
 const catBreed=Number.isInteger(raw.breed)&&raw.breed>=0&&raw.breed<PET_BREEDS.length?raw.breed:null;
 const locked=raw.locked===true&&(isDog||catBreed!==null);
 const rewards={};
 if(raw.rewardKeys&&typeof raw.rewardKeys==='object'&&!Array.isArray(raw.rewardKeys))for(const [key,value] of Object.entries(raw.rewardKeys).slice(-400)){if(/^[a-zA-Z0-9:_-]{1,90}$/.test(key)&&Number.isFinite(value))rewards[key]=Math.min(now,value)}
 const saneTime=(value,fallback)=>Number.isFinite(value)&&value>0?Math.min(now,value):fallback;
 S.petState={version:1,type:isDog?'dog':'cat',breed:isDog?'corgi':catBreed,gender:raw.gender==='male'?'male':'female',locked,xp:petClamp(raw.xp===undefined?initialXp:raw.xp,0,100000),foodLevel:petClamp(raw.foodLevel===undefined?S.energy:raw.foodLevel),waterLevel:petClamp(raw.waterLevel===undefined?85:raw.waterLevel),mood:petClamp(raw.mood===undefined?S.joy:raw.mood),health:petClamp(raw.health===undefined?100:raw.health,40,100),lastTick:saneTime(raw.lastTick,now),lastPracticeAt:saneTime(raw.lastPracticeAt,now),adoptedAt:saneTime(raw.adoptedAt,now),rewardKeys:rewards,behavior:['idle','sleep','play'].includes(raw.behavior)?raw.behavior:'idle'};
 S.water=petClamp(S.water===undefined?3:S.water,0,10000);
 if(!PET_SCENES.some(scene=>scene.id===S.scene))S.scene='jade';
 const clean={};const rawPositions=S.petRoomPositions;
 if(rawPositions&&typeof rawPositions==='object'&&!Array.isArray(rawPositions))for(const item of PS_FURNITURE){const value=rawPositions[item.id];if(Number.isInteger(value)&&value>=0&&value<PS_POSITIONS.length)clean[item.id]=value}
 S.petRoomPositions=clean;
 if(!S.petSettings||typeof S.petSettings!=='object')S.petSettings={};
 S.petSettings={muted:S.petSettings.muted!==false,animations:S.petSettings.animations!==false,roaming:S.petSettings.roaming!==false};
 S.energy=Math.round(S.petState.foodLevel);S.joy=Math.round(S.petState.mood);
 return S.petState;
}
function petApplyDecay(now=Date.now()){
 const p=S.petState||normalizePetState();const elapsed=Math.max(0,now-p.lastTick);
 if(elapsed<60000)return p;
 const days=elapsed/86400000;
 p.foodLevel=petClamp(p.foodLevel-days*16,15,100);
 p.waterLevel=petClamp(p.waterLevel-days*20,10,100);
 p.mood=petClamp(p.mood-days*10,25,100);
 if(now-p.lastPracticeAt>2*86400000&&(p.foodLevel<35||p.waterLevel<35))p.health=petClamp(p.health-days*5,40,100);
 p.lastTick=now;S.energy=Math.round(p.foodLevel);S.joy=Math.round(p.mood);save();return p;
}
function petStageIndex(){const xp=(S.petState||normalizePetState()).xp;return xp>=150?2:xp>=60?1:0}
function petStageName(){return ['Малыш','Подросток','Взрослый'][petStageIndex()]}
function petBreedName(){const p=S.petState||normalizePetState();return p.type==='dog'?'Корги':PET_BREEDS[p.breed===null?4:p.breed].name}
function petSprite(breed,cls='',label=''){
 const n=Number.isInteger(breed)?petClamp(breed,0,15):4;
 return `<span class="ps-cat-grid ${esc(cls)}" style="--ps-x:${(n%4)*100/3}%;--ps-y:${Math.floor(n/4)*100/3}%" role="img" aria-label="${esc(label||PET_BREEDS[n].name)}"></span>`;
}
function petMascot(cls=''){
 const p=S.petState||normalizePetState();
 if(p.type==='dog')return `<span class="ps-mascot ps-dog-grid ${esc(cls)}" data-stage="${petStageIndex()}" style="--ps-stage-x:${petStageIndex()*50}%" role="img" aria-label="Корги ${esc(S.pet)}, ${petStageName()}"></span>`;
 return petSprite(p.breed===null?4:p.breed,`ps-mascot ps-stage-${petStageIndex()} ${cls}`,`${S.pet}, ${petBreedName()}, ${petStageName()}`);
}
function petGrowthSprite(cls=''){
 const p=S.petState||normalizePetState(),stage=petStageIndex();
 if(p.type==='dog')return `<span class="ps-growth-sprite ps-growth-dog ${esc(cls)}" style="--ps-stage-x:${stage*50}%" role="img" aria-label="${esc(S.pet)}, ${petStageName()}"></span>`;
 const breed=p.breed===null?4:p.breed;const col=(breed%4)*3+stage,row=Math.floor(breed/4);
 return `<span class="ps-growth-sprite ps-growth-cat ps-cat-age-${stage} ${esc(cls)}" style="--ps-gx:${col*100/11}%;--ps-gy:${row*100/3}%" role="img" aria-label="${esc(S.pet)}, ${petStageName()}"></span>`;
}
function petBehavior(){const p=petApplyDecay();if(p.behavior==='sleep')return {state:'sleep',label:'Тихо отдыхает',line:'Небольшой отдых — и снова к открытиям.'};if(p.foodLevel<35)return {state:'idle',label:'Пора перекусить',line:'Немного еды и заботы вернут силы.'};if(p.waterLevel<35)return {state:'idle',label:'Хочется водички',line:'Поставьте свежую воду для вашего друга.'};if(p.health<70)return {state:'idle',label:'Нужны забота и отдых',line:'Учёба, вода и угощения помогут восстановиться.'};if(p.mood<50)return {state:'idle',label:'Соскучился по вам',line:'Давайте поиграем и выучим что-нибудь вместе.'};if(p.behavior==='play')return {state:'play',label:'Готов к игре',line:'Любопытство — наш общий язык.'};return {state:'idle',label:'Рад вас видеть',line:'Ваш маленький напарник всегда рядом.'}}
function petLearningReward(first,score,total){
 const p=petApplyDecay();const correct=petClamp(score,0,1000),all=petClamp(total,1,1000);if(correct<Math.ceil(all*.6))return {food:0,water:0,xp:0};
 const id=typeof session!=='undefined'&&session&&typeof session.id==='string'?session.id:'practice';
 const stableId=id.replace(/[^a-zA-Z0-9:_-]/g,'').slice(0,70);
 const key=id==='daily'?`daily:${today()}`:first?`lesson:${stableId}`:`day:${today()}`;
 p.lastPracticeAt=Date.now();p.behavior='idle';
 if(p.rewardKeys[key]||(id==='daily'&&!first)){save();return {food:0,water:0,xp:0}}
 const ratio=correct/all;const award={food:first?(ratio>=.9?3:2):1,water:first?2:1,xp:first?30:8};
 p.rewardKeys[key]=Date.now();p.xp=petClamp(p.xp+award.xp,0,100000);S.food=petClamp(S.food+award.food,0,10000);S.water=petClamp(S.water+award.water,0,10000);p.mood=petClamp(p.mood+8);p.health=petClamp(p.health+5,40,100);S.joy=Math.round(p.mood);save();return award;
}
function petSelectionPage(){
 const p=petApplyDecay();
 if(p.locked)return back('Ваш напарник','pet')+`<div class="ps-selection-complete">${petMascot('ps-selected-large')}<span class="tag lime">ВМЕСТЕ С ${new Date(p.adoptedAt).toLocaleDateString('ru-RU')}</span><h1>${esc(S.pet)}</h1><p>${petBreedName()} · ${p.gender==='female'?'Девочка':'Мальчик'}</p><div class="ps-help">Вы выбрали друг друга. Напарник сохраняется навсегда; имя и оформление комнаты можно менять.</div><button class="primary full" onclick="go('pet')">К моему другу →</button></div>`;
 const dog=petDraft.type==='dog';
 return back('Выберите напарника',S.name?'pet':'welcome')+`<div class="ps-selection-intro"><span class="eyebrow">МАЛЕНЬКИЙ ДРУГ · БОЛЬШОЙ ПУТЬ</span><h1>С кем начнём<br>путешествие?</h1><p>Один напарник — на всю вашу историю.</p></div><div class="tabs"><button class="${!dog?'active':''}" onclick="petChooseType('cat')">Котёнок</button><button class="${dog?'active':''}" onclick="petChooseType('dog')">Щенок</button></div>${dog?`<button class="ps-breed ps-dog-option ps-selected" onclick="petChooseType('dog')"><span class="ps-dog-preview" role="img" aria-label="Щенок корги"></span><strong>Корги</strong><small>Маленький исследователь с большим сердцем</small><span class="ps-breed-check">✓</span></button>`:`<div class="ps-breeds">${PET_BREEDS.map((breed,i)=>`<button class="ps-breed ${petDraft.breed===i?'ps-selected':''}" onclick="petChooseBreed(${i})" aria-pressed="${petDraft.breed===i}">${petSprite(i)}<strong>${breed.name}</strong>${petDraft.breed===i?'<span class="ps-breed-check">✓</span>':''}</button>`).join('')}</div>`}<div class="ps-gender"><span>Ваш напарник</span><div class="tabs"><button class="${petDraft.gender==='female'?'active':''}" onclick="petDraft.gender='female';render()">♀ Девочка</button><button class="${petDraft.gender==='male'?'active':''}" onclick="petDraft.gender='male';render()">♂ Мальчик</button></div></div><label class="form-label" for="ps-pet-name">Имя напарника</label><input id="ps-pet-name" class="field" maxlength="20" value="${esc(petDraft.name??S.pet??'Бао')}" oninput="petDraft.name=this.value" placeholder="Например, Бао"><button class="primary full" onclick="confirmPetSelection()">Мы нашли друг друга ♡</button><p class="ps-help">После подтверждения вид и породу нельзя изменить. Ваш существующий прогресс останется на месте.</p>`;
}
function petChooseType(type){petDraft.type=type==='dog'?'dog':'cat';if(petDraft.type==='dog'){if(Number.isInteger(petDraft.breed))petDraft.catBreed=petDraft.breed;petDraft.breed='corgi'}else petDraft.breed=Number.isInteger(petDraft.catBreed)?petDraft.catBreed:4;render()}
function petChooseBreed(index){if(!Number.isInteger(index)||index<0||index>15)return;petDraft.type='cat';petDraft.breed=index;petDraft.catBreed=index;render()}
function confirmPetSelection(){
 const p=S.petState||normalizePetState();if(p.locked){toast('Ваш напарник уже выбран.');return}
 const input=$('#ps-pet-name');const name=(input?input.value:(petDraft.name??S.pet??'Бао')).trim().slice(0,20);if(!name)return toast('Придумайте имя вашему другу.');
 if(petDraft.type==='cat'&&(!Number.isInteger(petDraft.breed)||petDraft.breed<0||petDraft.breed>15))return toast('Выберите котёнка.');
 const type=petDraft.type==='dog'?'dog':'cat';const breed=type==='dog'?'corgi':petDraft.breed;
 modal('Ваш друг навсегда',`<div class="ps-confirm">${type==='cat'?petSprite(breed,'ps-confirm-cat'): '<span class="ps-dog-preview" role="img" aria-label="Корги"></span>'}<h2>${esc(name)}</h2><p>${type==='dog'?'Корги':PET_BREEDS[breed].name} · ${petDraft.gender==='male'?'Мальчик':'Девочка'}</p></div><p>Выбор породы закрепится за этим профилем. Имя, сцену и мебель можно будет менять.</p><button class="secondary full" id="ps-adopt-confirm">Да, это мой напарник ♡</button>`);
 $('#ps-adopt-confirm').onclick=()=>{if(S.petState.locked)return closeModal();S.pet=name;S.petState.type=type;S.petState.breed=breed;S.petState.gender=petDraft.gender==='male'?'male':'female';S.petState.locked=true;S.petState.adoptedAt=Date.now();S.petState.lastTick=Date.now();save();closeModal();go('scenes');render();toast('Теперь вы вместе. 你好, '+name+'!')};
}
function petStatusRows(){const p=petApplyDecay();return `<div class="ps-status">${[['Сытость',p.foodLevel,'food'],['Вода',p.waterLevel,'water'],['Настроение',p.mood,'mood'],['Здоровье',p.health,'health']].map(([name,value,type])=>`<div class="ps-status-row"><span>${name}</span><div class="ps-status-track ps-${type}"><i style="width:${Math.round(value)}%"></i></div><b>${Math.round(value)}%</b></div>`).join('')}</div>`}
function petCompanionPage(){
 const p=petApplyDecay(),behavior=petBehavior();
 if(!p.locked)return back('Мой напарник','home')+`<div class="ps-unbound"><div class="ps-selection-collage">${[0,1,3].map(i=>petSprite(i)).join('')}</div><h1>Выберите своего друга</h1><p>Котёнок или щенок будет расти вместе с вашими знаниями китайского.</p><button class="primary full" onclick="go('pet-select')">Познакомиться →</button></div>`;
 const level=1+Math.floor(p.xp/30);return `<div class="pet-title"><div><span class="eyebrow">${petBreedName()}</span><h1>${esc(S.pet)} <span class="tag orange">Ур. ${level}</span></h1></div><button class="text" onclick="renamePet()">Изменить имя</button></div><div class="ps-free-companion-space"><span class="ps-free-companion-anchor" data-pet-hero aria-hidden="true"></span></div>${petStatusRows()}<div class="ps-care-actions"><button onclick="feedPet()"><span>🥣</span><strong>Покормить</strong><small>Корм · ${S.food}</small></button><button onclick="petGiveWater()"><span>💧</span><strong>Дать воды</strong><small>Вода · ${S.water}</small></button><button onclick="playPet()"><span>🪶</span><strong>Поиграть</strong><small>Настроение +12</small></button><button onclick="petRest()"><span>☾</span><strong>${p.behavior==='sleep'?'Разбудить':'Отдых'}</strong><small>Забота и покой</small></button></div><div class="grid" style="margin-top:16px">${feature('⌂','Маленький дом','Книги, мебель и уют','room')}${feature('◎','Путешествия','Открываем Китай вместе','travel')}</div><button class="ps-growth-link" onclick="go('pet-growth')"><span>🌱</span><div><strong>Растём вместе</strong><small>${p.xp} опыта · ${petStageName()}</small></div>${chevron}</button><div class="ps-learning-reward"><span>📖</span><div><h3>Учитесь — заботьтесь</h3><p>Новый урок приносит корм, воду и опыт. За повторение — небольшой бонус один раз в день.</p></div></div><button class="primary full" onclick="go('learn')">Учиться вместе →</button>`;
}
function petFeedAction(){const p=petApplyDecay();if(!p.locked)return go('pet-select');if(S.food<1)return toast('Нужно угощение: пройдите урок или загляните в магазин.');if(p.foodLevel>=98)return toast('Ваш друг уже сыт. Можно поиграть!');S.food--;p.foodLevel=petClamp(p.foodLevel+24);p.mood=petClamp(p.mood+4);p.health=petClamp(p.health+4,40,100);p.behavior='idle';S.energy=Math.round(p.foodLevel);S.joy=Math.round(p.mood);save();render();toast('谢谢! '+S.pet+' с удовольствием поел.');}
function petGiveWater(){const p=petApplyDecay();if(!p.locked)return go('pet-select');if(S.water<1)return toast('Пройдите небольшую практику, чтобы получить воду.');if(p.waterLevel>=98)return toast('Свежая вода уже есть — спасибо за заботу.');S.water--;p.waterLevel=petClamp(p.waterLevel+30);p.health=petClamp(p.health+4,40,100);p.behavior='idle';save();render();toast('Немного свежей воды — и снова хорошо.');}
function petPlayAction(){const p=petApplyDecay();if(!p.locked)return go('pet-select');if(p.foodLevel<22||p.waterLevel<20)return toast('Сначала немного еды и воды.');if(p.mood>=98)return toast('Настроение уже отличное! Давайте учиться.');p.mood=petClamp(p.mood+12);p.foodLevel=petClamp(p.foodLevel-3,15,100);p.behavior='play';S.energy=Math.round(p.foodLevel);S.joy=Math.round(p.mood);save();render();toast('Игра удалась! Настроение +12.');}
function petRest(){const p=petApplyDecay();p.behavior=p.behavior==='sleep'?'idle':'sleep';if(p.behavior==='sleep'&&!p.rewardKeys['rest:'+today()]){p.rewardKeys['rest:'+today()]=Date.now();p.health=petClamp(p.health+2,40,100);p.mood=petClamp(p.mood+2)}S.joy=Math.round(p.mood);save();render();toast(p.behavior==='sleep'?'Тс-с… напарник отдыхает.':'Доброе утро, маленький друг!');}
function petGrowthPage(){
 const p=petApplyDecay(),stage=petStageIndex(),next=stage===0?60:150;
 const growthStrip=p.type==='dog'?`<div class="ps-dog-growth-strip" role="img" aria-label="Три возраста корги"></div>`:`<div class="ps-cat-growth-strip" style="--ps-x:${((p.breed??4)%4)*100/3}%;--ps-y:${Math.floor((p.breed??4)/4)*100/3}%" role="img" aria-label="Три возраста выбранного котёнка"></div>`;
 return back('Растём вместе','pet','Знания растут — и ваш друг тоже.')+growthStrip+`<div class="ps-growth-milestones">${[['Малыш',0],['Подросток',60],['Взрослый',150]].map((s,i)=>`<div class="${i===stage?'ps-current':''}"><b>${i<=stage?'✓':i+1}</b><strong>${s[0]}</strong><small>${s[1]} опыта</small></div>`).join('')}</div><div class="card"><h2>${p.xp} опыта</h2><p>${stage===2?'Вы уже прошли большой путь вместе. Новые уроки продолжают приносить заботу и награды.':`До следующего этапа: ${Math.max(0,next-p.xp)} опыта.`}</p>${bar(stage===2?100:p.xp/next*100)}</div>${section('Маленькие открытия')}<div class="rows">${PS_FURNITURE.filter(x=>x.need>0).map(x=>`<div class="row"><span class="bubble">${x.icon}</span><span class="grow"><h3>${x.name}</h3><small>${x.need} опыта · для вашей комнаты</small></span><span class="tag ${p.xp>=x.need?'lime':''}">${p.xp>=x.need?'✓ Открыто':'Скоро'}</span></div>`).join('')}</div><div class="ps-help">Новый урок: +30 опыта. Успешное повторение: +8 опыта один раз в день. У каждого друга три возраста, а порода остаётся той же.</div>`;
}
function petUnlockedFurniture(){const p=petApplyDecay();return PS_FURNITURE.filter(item=>item.item?(S.inventory||[]).includes(item.item):p.xp>=item.need)}
function petRoomPage(){
 const p=petApplyDecay();if(!p.locked)return petCompanionPage();const furniture=petUnlockedFurniture(),scene=PET_SCENES.find(x=>x.id===S.scene)||PET_SCENES[0],behavior=petBehavior();
 const current=furniture.find(x=>x.id===petFurnitureSelected)||furniture[0];petFurnitureSelected=current.id;
 return back('Маленький дом','pet',scene.name)+`<div class="ps-room ps-theme-${S.scene} ${S.petSettings.animations?'':'ps-still'}"><div class="ps-room-window"><span>${S.scene==='night'?'☾':'☀'}</span><i></i></div><div class="ps-wall-art">学<br><small>一点一点</small></div><div class="ps-room-floor"></div>${furniture.map(item=>{const pos=PS_POSITIONS[S.petRoomPositions[item.id]??item.slot];return `<button class="ps-room-furniture ps-furniture-${item.id} ${current.id===item.id?'ps-furniture-selected':''}" style="--ps-left:${pos.x}%;--ps-top:${pos.y}%" onclick="${item.kind==='books'?"go('books')":`petFurnitureSelected='${item.id}';render()`}" aria-label="${item.name}${item.kind==='books'?', открыть книги':', выбрать для перестановки'}">${item.id==='shelf'?'<span class="ps-bookshelf"><i></i><i></i><i></i><b>书</b></span>':`<span>${item.icon}</span>`}${item.id==='shelf'?`<small>${S.books.length+2} книги</small>`:''}</button>`}).join('')}<div class="ps-room-pet ps-behavior-${behavior.state}">${petGrowthSprite()}</div><span class="ps-room-name">${esc(S.pet)} · ${petStageName()}</span></div><div class="ps-room-actions"><button class="outline" onclick="go('scenes')">◈ Сменить сцену</button><button class="outline" onclick="go('shop')">＋ В магазин</button></div>${section('Расставьте всё по-своему')}<div class="card"><label class="form-label" for="ps-furniture" style="margin-top:0">Предмет</label><select id="ps-furniture" class="field" onchange="petFurnitureSelected=this.value;render()">${furniture.map(item=>`<option value="${item.id}" ${item.id===current.id?'selected':''}>${item.name}</option>`).join('')}</select><label class="form-label" for="ps-position">Расположение</label><select id="ps-position" class="field" onchange="petMoveFurniture('${current.id}',this.value)">${PS_POSITIONS.map((pos,i)=>`<option value="${i}" ${i===(S.petRoomPositions[current.id]??current.slot)?'selected':''}>${pos.label}</option>`).join('')}</select><p class="ps-help" style="margin-bottom:0">Нажмите на книжную полку в комнате, чтобы открыть свои тексты, заметки и учебник.</p></div>${section('Ещё больше уюта','Развитие','pet-growth')}<div class="ps-room-unlocks">${PS_FURNITURE.filter(x=>x.need>p.xp).map(x=>`<span>${x.icon} ${x.name} · ${x.need} опыта</span>`).join('')||'<span>Все предметы роста открыты. Загляните в магазин за декором.</span>'}</div>`;
}
function petMoveFurniture(id,value){if(!PS_FURNITURE.some(item=>item.id===id)||!petUnlockedFurniture().some(item=>item.id===id))return;const pos=Number(value);if(!Number.isInteger(pos)||pos<0||pos>=PS_POSITIONS.length)return;S.petRoomPositions[id]=pos;save();render();toast('Теперь здесь ещё уютнее.');}
function petScenesPage(){return back('Сцена вашего мира','room','Одна атмосфера — во всём приложении.')+`<div class="ps-scenes">${PET_SCENES.map(scene=>`<button class="ps-scene-choice ps-theme-${scene.id} ${S.scene===scene.id?'ps-active-scene':''}" onclick="petChooseScene('${scene.id}')"><span class="ps-scene-art">${scene.emoji}<b>${scene.cn}</b></span><span><strong>${scene.name}</strong><small>${scene.desc}</small></span>${S.scene===scene.id?'<i>✓</i>':''}</button>`).join('')}</div><div class="ps-help">Сцена меняет фон комнаты и палитру интерфейса. Все четыре оформления доступны сразу.</div><button class="primary full" onclick="go('home')">Всё готово — начнём учиться →</button>`}
function petChooseScene(id){if(!PET_SCENES.some(x=>x.id===id))return;S.scene=id;document.documentElement.dataset.scene=id;save();render();toast('Сцена обновлена.');}
function petToggleAnimations(value){S.petSettings.animations=!!value;save();render();}
function petToggleMuted(value){S.petSettings.muted=!!value;S.muted=!!value;save();render();}
function initPetSystem(){
 normalizePetState();petApplyDecay();
 petDraft={type:S.petState.type,breed:S.petState.breed===null?4:S.petState.breed,catBreed:Number.isInteger(S.petState.breed)?S.petState.breed:4,gender:S.petState.gender,name:S.pet||'Бао'};
 mascot=petMascot;petPage=petCompanionPage;roomPage=petRoomPage;feedPet=petFeedAction;playPet=petPlayAction;
 document.documentElement.dataset.scene=S.scene;
 if(!petSystemInitialized){petSystemInitialized=true;window.addEventListener('focus',()=>{petApplyDecay();if(location.hash.slice(1).split('/')[0]==='pet'&&!document.querySelector('dialog[open]'))render()});document.addEventListener('visibilitychange',()=>{if(!document.hidden)petApplyDecay()})}
 save();return S.petState;
}
