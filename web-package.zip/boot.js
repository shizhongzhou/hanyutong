initExperienceState();initPetSystem();S.petSettings.muted=S.muted;applyAppScene();save();render();updateOffline();if(typeof initPetMotion==='function')initPetMotion();
const exFeedPet=feedPet,exPlayPet=playPet,exRestPet=petRest;feedPet=function(){const before=S.food;exFeedPet();if(S.food<before&&typeof petMotionReact==='function')petMotionReact('feed')};playPet=function(){exPlayPet();if(typeof petMotionReact==='function')petMotionReact('play')};petRest=function(){if(typeof getPetMotionState==='function'&&getPetMotionState().sleeping&&typeof callPetWake==='function'){callPetWake();return}exRestPet();if(typeof petMotionReact==='function')petMotionReact('rest')};

initInteractionUI();
