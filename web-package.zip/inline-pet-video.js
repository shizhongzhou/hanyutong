'use strict';
/* Local, silent packed-alpha video widgets. No media permission is requested. */
const INLINE_PET_VIDEO_MATH=(()=>{
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 function combineAlpha(rgb,mask){if(!rgb?.data||!mask?.data||rgb.data.length!==mask.data.length)throw Error('Packed panels differ');for(let i=0;i<rgb.data.length;i+=4)rgb.data[i+3]=mask.data[i];return rgb}
 function mediaPath(value,extensions){return typeof value==='string'&&!value.includes('..')&&new RegExp('^assets/motion/[a-zA-Z0-9_.\\/-]+\\.('+extensions+')$','i').test(value)}
 function normalize(clip){if(!clip||typeof clip!=='object')return null;const poster=mediaPath(clip.poster,'png|webp')?clip.poster:null,endPoster=mediaPath(clip.endPoster,'png|webp')?clip.endPoster:null;const packed=clip.kind==='alpha-video'&&clip.alphaLayout==='side-by-side'&&mediaPath(clip.src,'mp4')&&Number.isInteger(clip.contentWidth)&&clip.contentWidth>=16&&clip.contentWidth<=2048&&Number.isInteger(clip.contentHeight)&&clip.contentHeight>=16&&clip.contentHeight<=2048;return {src:packed?clip.src:null,poster,endPoster,contentWidth:clip.contentWidth,contentHeight:clip.contentHeight,groundPaddingPx:clamp(Number(clip.groundPaddingPx)||0,0,8),fps:Number(clip.fps)||0,loop:clip.loopSafe===true&&(clip.state==='idle'||clip.action==='idle'||/idle/.test(String(clip.id||'')))} }
 return {clamp,combineAlpha,mediaPath,normalize};
})();
function inlinePetVideoMarkup(clip,attrs={}){
 const c=INLINE_PET_VIDEO_MATH.normalize(clip);if(!c)return '';
 const escape=value=>String(value??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
 const width=INLINE_PET_VIDEO_MATH.clamp(Number(attrs.width)||146,24,640),height=INLINE_PET_VIDEO_MATH.clamp(Number(attrs.height)||104,24,640);
 const classes=String(attrs.className||'').split(/\s+/).filter(x=>/^[a-zA-Z0-9_-]+$/.test(x)).join(' '),id=attrs.id?` id="${escape(attrs.id)}"`:'';
 return `<span${id} class="ipv-widget ${classes}" data-inline-pet-video="${escape(JSON.stringify(clip))}" data-ipv-width="${width}" data-ipv-height="${height}"${attrs.phase?` data-phase="${escape(attrs.phase)}"`:''} style="width:${width}px;height:${height}px" ${attrs.label?`role="img" aria-label="${escape(attrs.label)}"`:'aria-hidden="true"'}><canvas class="ipv-canvas" hidden></canvas><img class="ipv-poster"${c.poster?` src="${escape(c.poster)}"`:''} alt=""${c.poster?'':' hidden'}><video class="ipv-source" muted playsinline webkit-playsinline preload="auto" aria-hidden="true"></video></span>`;
}
const InlinePetVideos=(()=>{
 const players=new Map();let installed=false,observer=null;
 function blocked(root){if(document.hidden||!root.isConnected||root.closest('[hidden]'))return true;const dialog=root.closest('dialog');return !!dialog&&!dialog.open}
 function cancelFrames(s){s.frameVersion++;if(s.vfc!==null&&s.video.cancelVideoFrameCallback)s.video.cancelVideoFrameCallback(s.vfc);if(s.raf!==null)cancelAnimationFrame(s.raf);s.vfc=null;s.raf=null}
 function pause(s){cancelFrames(s);s.playAttempt++;s.playPending=false;if(!s.video.paused)s.video.pause()}
 function poster(s,state){if(s.clip.poster){s.poster.hidden=false;s.canvas.hidden=true}s.root.dataset.inlineState=state}
 function release(s){if(s.destroyed)return;s.destroyed=true;pause(s);s.listeners.forEach(([target,event,fn])=>target.removeEventListener(event,fn));s.listeners.length=0;s.video.removeAttribute('src');try{s.video.load()}catch{}s.raw.width=s.raw.height=1;players.delete(s.root)}
 function listen(s,target,event,fn){target.addEventListener(event,fn);s.listeners.push([target,event,fn])}
 function geometry(s){const rect=s.root.getBoundingClientRect();const dpr=INLINE_PET_VIDEO_MATH.clamp(window.devicePixelRatio||1,1,2);return {width:Math.max(1,Math.round((rect.width||Number(s.root.dataset.ipvWidth)||146)*dpr)),height:Math.max(1,Math.round((rect.height||Number(s.root.dataset.ipvHeight)||104)*dpr))}}
 function draw(s){
  if(s.destroyed||blocked(s.root)||s.video.readyState<2)return false;
  const c=s.clip;if(s.video.videoWidth!==c.contentWidth*2||s.video.videoHeight!==c.contentHeight){fail(s,'invalid-dimensions');return false}
  try{
   const size=geometry(s),scale=Math.min(size.width/c.contentWidth,size.height/c.contentHeight),w=Math.max(1,Math.round(c.contentWidth*scale)),h=Math.max(1,Math.round(c.contentHeight*scale));
   if(s.canvas.width!==size.width||s.canvas.height!==size.height){s.canvas.width=size.width;s.canvas.height=size.height}
   if(s.raw.width!==w*2||s.raw.height!==h){s.raw.width=w*2;s.raw.height=h}
   s.rawCtx.clearRect(0,0,w*2,h);s.rawCtx.drawImage(s.video,0,0,c.contentWidth*2,c.contentHeight,0,0,w*2,h);
   const color=s.rawCtx.getImageData(0,0,w,h),alpha=s.rawCtx.getImageData(w,0,w,h);INLINE_PET_VIDEO_MATH.combineAlpha(color,alpha);s.rawCtx.putImageData(color,0,0);
   s.ctx.clearRect(0,0,size.width,size.height);s.ctx.drawImage(s.raw,0,0,w,h,(size.width-w)/2,size.height-h+c.groundPaddingPx*scale,w,h);
   s.canvas.hidden=false;s.poster.hidden=true;s.hasFrame=true;s.root.dataset.inlineRender='alpha-video';s.root.dataset.inlineState=s.settled?'ended':'playing';s.root.dataset.inlineFps=String(c.fps||'native');return true;
  }catch{fail(s,'render-error');return false}
 }
 function schedule(s){
  if(s.destroyed||s.settled||s.failed||blocked(s.root)||s.video.paused)return;
  if(s.video.requestVideoFrameCallback){
   if(s.vfc!==null)return;
   const generation=s.frameVersion;s.vfc=s.video.requestVideoFrameCallback((_time,meta)=>{if(generation!==s.frameVersion)return;s.vfc=null;if(s.destroyed||s.settled||blocked(s.root)||s.video.paused)return;draw(s);s.frames=meta?.presentedFrames||s.frames+1;s.root.dataset.inlineFrame=String(s.frames);schedule(s)});
  }else if(s.raf===null){
   const generation=s.frameVersion;s.raf=requestAnimationFrame(()=>{if(generation!==s.frameVersion)return;s.raf=null;if(s.destroyed||s.settled||blocked(s.root)||s.video.paused)return;if(s.lastTime!==s.video.currentTime){s.lastTime=s.video.currentTime;if(draw(s)){s.frames++;s.root.dataset.inlineFrame=String(s.frames)}}schedule(s)});
  }
 }
 function fail(s,reason){if(s.destroyed)return;s.failed=true;s.needsGesture=true;pause(s);poster(s,reason);s.root.dataset.inlineRender='poster'}
 function play(s,explicit=false){
  if(s.destroyed||s.settled||blocked(s.root)||!s.clip.src||s.playPending||s.failed&&!explicit||s.needsGesture&&!explicit)return;
  if(!s.video.paused){schedule(s);return}
  if(explicit&&s.failed){s.failed=false;s.video.load()}
  s.needsGesture=false;s.playPending=true;const attempt=++s.playAttempt;let promise;
  try{promise=s.video.play()}catch{if(attempt===s.playAttempt){s.playPending=false;s.needsGesture=true;poster(s,'gesture-needed')}return}
  Promise.resolve(promise).then(()=>{if(s.destroyed||attempt!==s.playAttempt)return;s.playPending=false;if(blocked(s.root)){pause(s);return}schedule(s)}).catch(()=>{if(s.destroyed||attempt!==s.playAttempt)return;s.playPending=false;s.needsGesture=true;cancelFrames(s);poster(s,'gesture-needed');s.root.dataset.inlineRender='poster'});
 }
 function finish(s){if(s.destroyed||s.clip.loop)return;draw(s);pause(s);s.settled=true;s.root.dataset.inlineState='ended';if(s.clip.endPoster){s.posterTarget='end';s.poster.src=s.clip.endPoster;if(s.poster.complete&&s.poster.naturalWidth){s.poster.hidden=false;s.canvas.hidden=true;s.root.dataset.inlineRender='end-poster'}}}
 function init(root){
  let rawClip;try{rawClip=JSON.parse(root.dataset.inlinePetVideo)}catch{return}const clip=INLINE_PET_VIDEO_MATH.normalize(rawClip);if(!clip)return;
  const video=root.querySelector('.ipv-source'),canvas=root.querySelector('.ipv-canvas'),posterImage=root.querySelector('.ipv-poster');if(!video||!canvas||!posterImage)return;
  const raw=document.createElement('canvas'),s={root,clip,signature:root.dataset.inlinePetVideo,video,canvas,poster:posterImage,raw,ctx:canvas.getContext('2d'),rawCtx:raw.getContext('2d',{willReadFrequently:true}),listeners:[],vfc:null,raf:null,frameVersion:0,frames:0,lastTime:null,hasFrame:false,settled:false,destroyed:false,failed:false,needsGesture:false,playPending:false,playAttempt:0,posterTarget:'start'};
  if(!s.ctx||!s.rawCtx)return;players.set(root,s);root.dataset.inlineState='loading';root.dataset.inlineRender='poster';
  listen(s,posterImage,'load',()=>{if(!s.destroyed&&s.posterTarget==='end'&&s.settled){s.poster.hidden=false;s.canvas.hidden=true;s.root.dataset.inlineState='ended';s.root.dataset.inlineRender='end-poster'}});
  listen(s,posterImage,'error',()=>{if(s.hasFrame){s.canvas.hidden=false;s.poster.hidden=true}else s.poster.hidden=true});
  if(!clip.src){root.dataset.inlineState='poster-only';return}
  video.muted=true;video.defaultMuted=true;video.playsInline=true;video.loop=clip.loop;video.preload='auto';
  listen(s,video,'loadeddata',()=>{if(s.destroyed||blocked(root))return;draw(s);play(s)});
  listen(s,video,'playing',()=>schedule(s));listen(s,video,'ended',()=>finish(s));listen(s,video,'error',()=>fail(s,'media-error'));
  video.src=clip.src;video.load();play(s);
 }
 function update(){
  install();for(const s of [...players.values()]){if(!s.root.isConnected||s.root.closest('dialog')&&!s.root.closest('dialog').open||s.signature!==s.root.dataset.inlinePetVideo){release(s);continue}if(blocked(s.root)){pause(s);if(!s.settled)s.root.dataset.inlineState='paused'}else play(s)}
  document.querySelectorAll('[data-inline-pet-video]').forEach(root=>{if(!players.has(root)&&!blocked(root))init(root)});
 }
 function visibility(){update()}
 function gesture(){for(const s of players.values())if(s.needsGesture&&!blocked(s.root))play(s,true)}
 function install(){if(installed)return;installed=true;document.addEventListener('visibilitychange',visibility);document.addEventListener('pointerdown',gesture,{passive:true});if(typeof MutationObserver!=='undefined'&&document.body){observer=new MutationObserver(update);observer.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['open','hidden','data-inline-pet-video']})}}
 function destroy(){for(const s of [...players.values()])release(s);observer?.disconnect();observer=null;if(installed){document.removeEventListener('visibilitychange',visibility);document.removeEventListener('pointerdown',gesture)}installed=false}
 function setClip(root,clip){if(typeof root==='string')root=document.getElementById(root);if(!root)return;root.dataset.inlinePetVideo=JSON.stringify(clip);const s=players.get(root);if(s&&s.signature!==root.dataset.inlinePetVideo)release(s);update()}
 return {update,destroy,setClip,stats:()=>({players:players.size,callbacks:[...players.values()].filter(s=>s.vfc!==null||s.raf!==null).length})};
})();
function updateInlinePetVideos(){InlinePetVideos.update()}
function setInlinePetVideoClip(root,clip){InlinePetVideos.setClip(root,clip)}
function destroyInlinePetVideos(){InlinePetVideos.destroy()}
