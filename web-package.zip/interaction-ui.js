'use strict';
let absenceLocked=false,recordPetChargeAt=0;
function orangeClip(action){const list=PET_INTERACTION_CLIPS?.clips||[];const stage=petStageIndex();return list.find(c=>(c.action===action||(Array.isArray(c.actions)&&c.actions.includes(action)))&&(c.stage===stage||Array.isArray(c.stages)&&c.stages.includes(stage)))||list.find(c=>c.action===action)}
function clipById(id){return (PET_MOTION_CLIPS?.clips||[]).find(c=>c.id===id)||(PET_INTERACTION_CLIPS?.clips||[]).find(c=>c.id===id)}
function ownOrange(){return S.petState?.type==='cat'&&S.petState?.breed===0}
function markLearningActivity(){S.lastLearningAt=Date.now();if(S.petState)S.petState.lastPracticeAt=S.lastLearningAt;save()}
const iuNextQuestion=nextQuestion;nextQuestion=function(){const finish=!!session&&!session.finished&&session.selected!==null&&session.pos+1>=session.words.length;iuNextQuestion();if(finish)markLearningActivity()};
const iuWriting=studySaveWriting;studySaveWriting=function(value){iuWriting(value);if(String(value).trim())markLearningActivity()};
const iuSpeech=speak;speak=function(text){iuSpeech(text);if(!S.muted&&typeof text==='string'&&/[\u3400-\u9fff]/.test(text))markLearningActivity()};
function recorderPetMarkup(){if(!ownOrange())return `<div class="iu-recorder-pet" aria-hidden="true">${mascot()}</div>`;const recording=ssSpeech.recorder?.state==='recording';const charging=ssSpeech.pending||recording&&Date.now()-recordPetChargeAt<800;const clip=clipById(charging?'kitten-stretch':recording?'kitten-walk':'kitten-idle');return `<div class="iu-recorder-pet" aria-hidden="true">${typeof inlinePetVideoMarkup==='function'&&clip?.kind==='alpha-video'?inlinePetVideoMarkup(clip,{id:'iu-record-cat',phase:charging?'charge':recording?'move':'idle',width:146,height:104}):`<img id="iu-record-cat" src="${clip?.src||'assets/motion/kitten-idle-alpha.webp'}" alt="" data-phase="${charging?'charge':recording?'move':'idle'}">`}</div>`}
function setRecorderCatClip(el,clip,phase){if(!el||!clip)return;el.dataset.phase=phase;if(el.hasAttribute?.('data-inline-pet-video')&&typeof setInlinePetVideoClip==='function')setInlinePetVideoClip(el,clip);else el.src=clip.src}
function updateRecorderPet(){const el=$('#iu-record-cat');if(!el||!ownOrange())return;const recording=ssSpeech.recorder?.state==='recording';const charging=ssSpeech.pending||recording&&Date.now()-recordPetChargeAt<800;const phase=charging?'charge':recording?'move':'idle';if(el.dataset.phase!==phase)setRecorderCatClip(el,clipById(charging?'kitten-stretch':recording?'kitten-walk':'kitten-idle'),phase);if(typeof updateInlinePetVideos==='function')updateInlinePetVideos();if(recording&&charging)setTimeout(updateRecorderPet,Math.max(30,820-(Date.now()-recordPetChargeAt)))}
const iuSpeakingPage=speakingPage;speakingPage=function(){const html=iuSpeakingPage();const out=html.replace('<button class="ss-record-button',recorderPetMarkup()+'<button class="ss-record-button');setTimeout(updateRecorderPet,850);return out};
const iuStartRecording=studyStartRecording;studyStartRecording=async function(){recordPetChargeAt=Date.now();const el=$('#iu-record-cat');if(el&&ownOrange()){setRecorderCatClip(el,clipById('kitten-stretch'),'charge')}await iuStartRecording();if(ssSpeech.recorder?.state==='recording')markLearningActivity();updateRecorderPet()};
let iuToyBusyUntil=0;
function interactionPetSleeping(){if(S.petState?.behavior==='sleep')return true;try{const motion=typeof getPetMotionState==='function'?getPetMotionState():null;return !!motion?.sleeping||motion?.phase==='sleep'}catch{return false}}
function interactionWakePet(source='button'){if(typeof requestPetWake==='function')requestPetWake(source);else if(typeof callPetWake==='function')callPetWake();else toast('Питомец отдыхает. Дадим ему ещё немного времени.');updateInteractionUI();return false}
function petToyAction(kind,source='button'){
 if(!S.petState?.locked){go('pet-select');return false}
 if(interactionPetSleeping())return interactionWakePet(source);
 if(S.petState.foodLevel<20){if(source!=='shake')toast('Сначала немного еды и воды.');return false}
 const time=Date.now();let motion=null;try{motion=typeof getPetMotionState==='function'?getPetMotionState():null}catch{}
 if(time<iuToyBusyUntil||motion&&['feed','treat','teaser','ball','fish','whip','wake'].includes(motion.phase)&&(motion.animatedImageActive||motion.animatedImagePending)){if(source!=='shake')toast('Питомец уже занят — подождём немного.');return false}
 const accepted=typeof petMotionReact==='function'?petMotionReact(kind):false;if(accepted===false)return false;
 const clip=ownOrange()?orangeClip(kind):null;iuToyBusyUntil=time+Math.max(4300,Math.min(30000,Number(clip?.durationMs)||Number(clip?.duration)*1000||4300));
 S.petState.behavior='play';S.petState.mood=Math.min(100,S.petState.mood+4);S.joy=Math.round(S.petState.mood);save();updateInteractionUI();return true;
}
let iuPetPage=null;
function interactionPetPage(){
 let html=iuPetPage();if(!S.petState?.locked)return html;
 html+=`${section('Играем вместе')}<div class="iu-teaser-play"><button class="primary full iu-teaser-button" onclick="petToyAction('teaser')"><span aria-hidden="true">🪶</span> Поиграть с удочкой</button><button id="iu-wake-pet" class="outline full" onclick="interactionWakePet('button')" ${interactionPetSleeping()?'':'hidden'}>☀ Позвать проснуться</button><p id="iu-sleep-hint" ${interactionPetSleeping()?'':'hidden'}>Питомец спит. Сначала тихонько позовём его.</p><div class="iu-shake-controls"><button id="iu-shake-button" class="outline" onclick="togglePetShake()" aria-pressed="false">Включить встряхивание</button><p id="iu-shake-status" role="status" aria-live="polite"></p></div></div>${section('Игрушки и маленькие радости')}<div class="iu-toys"><button onclick="petToyAction('ball')"><span>🧶</span>Мячик</button><button onclick="petToyAction('fish')"><span>🐟</span>Подушка-рыбка</button><button onclick="petMotionReact('upper-right')"><span>↗</span>Посидеть рядом</button></div>`;return html;
}
/* Motion permission is requested only by togglePetShake's explicit button click.
   https://developer.mozilla.org/en-US/docs/Web/API/DeviceMotionEvent/requestPermission_static */
function createPetShakeDetector(){
 let gravity=null,peakAt=null,peakArmed=true,lastSample=0;
 return {reset(){gravity=null;peakAt=null;peakArmed=true;lastSample=0},sample(event,time){
  const valid=v=>v&&[v.x,v.y,v.z].every(x=>typeof x==='number'&&Number.isFinite(x)&&Math.abs(x)<150);
  let vector;if(valid(event.acceleration))vector={...event.acceleration};else if(valid(event.accelerationIncludingGravity)){
   const v=event.accelerationIncludingGravity;if(!gravity){gravity={x:v.x,y:v.y,z:v.z};lastSample=time;return false}
   const dt=Math.max(.01,Math.min(.2,(time-lastSample)/1000||.02)),blend=1-Math.exp(-dt/.25);vector={};for(const axis of ['x','y','z']){gravity[axis]+=blend*(v[axis]-gravity[axis]);vector[axis]=v[axis]-gravity[axis]}
  }else return false;
  lastSample=time;const strength=Math.hypot(vector.x,vector.y,vector.z);
  if(strength<4.5){peakArmed=true;return false}if(strength<11||!peakArmed)return false;peakArmed=false;
  if(peakAt!==null&&time-peakAt>=80&&time-peakAt<=650){peakAt=null;return true}peakAt=time;return false;
 }};
}
const iuShake={enabled:false,pending:false,permission:'unknown',mode:null,listening:false,nativeArmed:false,status:'off',lastTrigger:-Infinity,detector:createPetShakeDetector(),noDataTimer:0,validSamples:0};
let iuInteractionInitialized=false,iuModalObserver=null;
function nativeShakeBridge(){const bridge=window.LapkaNative;return bridge&&typeof bridge.setShakeEnabled==='function'&&typeof bridge.hasShakeSensor==='function'?bridge:null}
function interactionShakeAllowed(){const focused=document.activeElement;if(focused?.matches?.('input,textarea,select,[contenteditable="true"]'))return false;return !!S.petState?.locked&&(location.hash.slice(1).split('/')[0]||'home')==='pet'&&!document.hidden&&!document.querySelector('dialog[open]')&&S.petSettings?.roaming!==false&&S.petSettings?.animations!==false&&!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches}
function nativeShakeAvailable(){try{const result=nativeShakeBridge()?.hasShakeSensor();return result===true||result==='true'}catch{return false}}
function stopPetShake(){
 if(iuShake.listening){window.removeEventListener?.('devicemotion',onPetDeviceMotion);window.removeEventListener?.('hanyutun:shake',onNativePetShake)}
 if(iuShake.nativeArmed){try{nativeShakeBridge()?.setShakeEnabled(false)}catch{}}
 iuShake.listening=false;iuShake.nativeArmed=false;iuShake.detector.reset();clearTimeout(iuShake.noDataTimer);iuShake.noDataTimer=0;
}
function syncPetShake(){
 if(!iuShake.enabled||!interactionShakeAllowed()){stopPetShake();return}
 if(iuShake.listening){if(iuShake.mode==='native'&&!iuShake.nativeArmed){try{nativeShakeBridge()?.setShakeEnabled(true);iuShake.nativeArmed=true}catch{}}return}
 iuShake.detector.reset();iuShake.validSamples=0;
 if(iuShake.mode==='native'&&nativeShakeAvailable()){
  try{nativeShakeBridge().setShakeEnabled(true);iuShake.nativeArmed=true;window.addEventListener('hanyutun:shake',onNativePetShake);iuShake.listening=true;return}catch{iuShake.status='unavailable';iuShake.enabled=false;return}
 }
 if(iuShake.mode!=='browser'){iuShake.enabled=false;iuShake.status='unavailable';return}
 window.addEventListener('devicemotion',onPetDeviceMotion,{passive:true});iuShake.listening=true;
 iuShake.noDataTimer=setTimeout(()=>{if(iuShake.enabled&&iuShake.listening&&!iuShake.validSamples){iuShake.status='waiting';updateInteractionUI()}},6000);
}
async function togglePetShake(){
 if(iuShake.pending)return;if(iuShake.enabled){iuShake.enabled=false;iuShake.status='off';stopPetShake();updateInteractionUI();return}
 if(!interactionShakeAllowed()){toast('Сначала включите движения питомца в настройках.');updateInteractionUI();return}
 if(nativeShakeAvailable()){iuShake.mode='native';iuShake.permission='granted';iuShake.enabled=true;iuShake.status='on';updateInteractionUI();return}
 if(window.isSecureContext===false||typeof window.DeviceMotionEvent==='undefined'){iuShake.status='unavailable';updateInteractionUI();return}
 iuShake.pending=true;iuShake.status='pending';updateInteractionUI();
 try{
  // This call remains within the user's click event; no startup permission prompt.
  const permission=typeof window.DeviceMotionEvent.requestPermission==='function'?await window.DeviceMotionEvent.requestPermission():'granted';
  iuShake.permission=permission==='granted'?'granted':'denied';iuShake.enabled=permission==='granted';iuShake.mode=iuShake.enabled?'browser':null;iuShake.status=iuShake.enabled?'on':'denied';
 }catch{iuShake.permission='denied';iuShake.enabled=false;iuShake.status='denied'}
 finally{iuShake.pending=false;updateInteractionUI()}
}
function triggerPetShake(){
 if(!iuShake.enabled||!iuShake.listening||!interactionShakeAllowed()||Date.now()-iuShake.lastTrigger<5000)return false;
 if(Date.now()<iuToyBusyUntil)return false;iuShake.lastTrigger=Date.now();
 if(interactionPetSleeping()){interactionWakePet('shake');return true}
 return petToyAction('teaser','shake');
}
function onNativePetShake(){if(iuShake.mode==='native')triggerPetShake()}
function onPetDeviceMotion(event){
 if(iuShake.mode!=='browser'||!interactionShakeAllowed())return;
 const valid=v=>v&&[v.x,v.y,v.z].every(x=>typeof x==='number'&&Number.isFinite(x));if(valid(event.acceleration)||valid(event.accelerationIncludingGravity)){iuShake.validSamples++;if(iuShake.status==='waiting'){iuShake.status='on';updateInteractionUI()}}
 if(iuShake.detector.sample(event,Date.now()))triggerPetShake();
}
function updateInteractionUI(){
 syncPetShake();if(typeof updateInlinePetVideos==='function')updateInlinePetVideos();const button=$('#iu-shake-button'),status=$('#iu-shake-status'),wake=$('#iu-wake-pet'),hint=$('#iu-sleep-hint');
 if(button){button.textContent=iuShake.pending?'Разрешаем движения…':iuShake.enabled?'Выключить встряхивание':'Включить встряхивание';button.disabled=iuShake.pending;button.setAttribute('aria-pressed',iuShake.enabled?'true':'false');button.dataset.state=iuShake.enabled?'on':iuShake.status}
 if(status){const messages={off:'Можно помахать удочкой кнопкой или включить встряхивание телефона.',on:'Слегка покачайте телефон два раза — питомец поиграет с удочкой.',pending:'Разрешите движения телефона, если появится запрос.',denied:'Доступ не разрешён. С удочкой по-прежнему можно играть кнопкой.',unavailable:'Здесь встряхивание недоступно. Поиграйте с удочкой кнопкой.',waiting:'Телефон пока не передал движения. Можно играть кнопкой.'};status.textContent=iuShake.enabled&&!interactionShakeAllowed()?'Встряхивание приостановлено.':messages[iuShake.status]||messages.off}
 const sleeping=interactionPetSleeping();if(wake)wake.hidden=!sleeping;if(hint)hint.hidden=!sleeping;
}
function maybeAbsenceReminder(){if(absenceLocked||!S.petState?.locked||$('#modal').open)return;const last=Number(S.lastLearningAt)||Number(S.petState.lastPracticeAt)||Date.now();if(Date.now()-last<86400000||S.absenceAckDay===today())return;const clip=ownOrange()?orangeClip('whip'):null;const art=clip?clip.kind==='alpha-video'&&typeof inlinePetVideoMarkup==='function'?inlinePetVideoMarkup(clip,{className:'iu-reminder-animation',width:320,height:240,label:'Озорной напарник напоминает об учёбе'}):`<img class="iu-reminder-animation" src="${clip.src}" alt="Озорной напарник напоминает об учёбе">`:`<div class="iu-reminder-animation">${mascot()}</div>`;$('#modal').innerHTML=`<div class="iu-absence">${art}<h2>Эй, мы давно не учились!</h2><p>${esc(S.pet)} приготовил немного озорства.<br>Вернёмся к маленьким открытиям?</p><button class="primary full" id="iu-absence-ack">我错了 · Я исправлюсь</button></div>`;absenceLocked=true;$('#modal').showModal();if(typeof updateInlinePetVideos==='function')updateInlinePetVideos();$('#iu-absence-ack').onclick=()=>{S.absenceAckDay=today();save();absenceLocked=false;$('#modal').close();if(typeof updatePetMotion==='function')updatePetMotion()}}
$('#modal').addEventListener('cancel',e=>{if(absenceLocked)e.preventDefault()});
const iuCloseModal=closeModal;closeModal=function(){if(absenceLocked)return;iuCloseModal()};
function initInteractionUI(){
 if(!iuPetPage){iuPetPage=petPage;petPage=interactionPetPage;render()}
 if(!iuInteractionInitialized){
  iuInteractionInitialized=true;window.addEventListener('hashchange',updateInteractionUI);document.addEventListener('visibilitychange',updateInteractionUI);window.addEventListener('pagehide',stopPetShake);window.addEventListener('pageshow',updateInteractionUI);document.addEventListener('focusin',updateInteractionUI);document.addEventListener('focusout',()=>setTimeout(updateInteractionUI,0));window.addEventListener('hanyutun:resume',()=>{iuShake.nativeArmed=false;updateInteractionUI()});window.addEventListener('hanyutun:petstate',updateInteractionUI);
  if(typeof MutationObserver!=='undefined'&&$('#modal')){iuModalObserver=new MutationObserver(updateInteractionUI);iuModalObserver.observe($('#modal'),{attributes:true,attributeFilter:['open']})}
 }
 if(!Number.isFinite(S.lastLearningAt))S.lastLearningAt=Number(S.petState?.lastPracticeAt)||Date.now();save();updateInteractionUI();setTimeout(maybeAbsenceReminder,450);
}
